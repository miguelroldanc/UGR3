Run the program:

	PLYLOD.EXE

from this directory.

Use SPACE to cycle through the selections.
Hit ENTER when you want to load the 
current selection.
Depening on your computer you may
have to wait for a few seconds for
the (unoptimized) algorithm to
do the reduction.

The models are various VRML files taken
from the web and converted into
a form that is parsable in a 10 line
snippit of code.  (a few minutes work for any
1st year comp sci student)
Sorry, but there was no other option.
Writing a vrml parser for this
demo (or any other application)
is simply out of the question!
It would take years to implement, and would
require thorough knowledge of certain compiler tools
and the (massive) VRML specification.
Perhaps VRML would have actually become
a more widely used 3D file format 
had someone considered
how developers are supposed
to get the content into their own applications -
not just spin them from a web page.
Believe me, I would much rather have included a list of links
with this demo, instead of megabytes of data.
My deepest apologies to the creators
of the models (vrml content) used here.
This is just a freeware demo to illustrate an algorithm.
There is no commercial usage here.
This was initially just part of a class project for
a course: comp sci 503.  

If there are any concerns about copyright infringements
of certain models, then email - I can remove them.
Please dont hurt me.

Stan Melax
University of Alberta (PhD student)
mailto:melax@cs.ualberta.ca


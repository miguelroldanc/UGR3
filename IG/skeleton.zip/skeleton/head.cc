#include "head.h"

void _head::changeEsferaIzda(){
    glTranslatef(-1.5,1.5,4);
    glScalef(2,2,2);
}
void _head::changeEsferaDcha(){
    glTranslatef(1.5,1.5,4);
    glScalef(2,2,2);
}
void _head::changeSemi(){
    glRotatef(180,1,0,0);
    glScalef(10,10,10);
}
void _head::changeAntenaDcha(){
    glTranslatef(3,5,0);
    glRotatef(-30,0,0,1);
}
void _head::changeAntenaIzda(){
    glTranslatef(-3,5,0);
    glRotatef(30,0,0,1);
}
void _head::draw_point(){
    glPushMatrix();
    changeSemi();
    Semi.draw_point();
    glPopMatrix();

    glPushMatrix();
    changeEsferaDcha();
    Esfera.draw_point();
    glPopMatrix();

    glPushMatrix();
    changeEsferaIzda();
    Esfera.draw_point();
    glPopMatrix();

    glPushMatrix();
    changeAntenaDcha();
    Antena.draw_point();
    glPopMatrix();

    glPushMatrix();
    changeAntenaIzda();
    Antena.draw_point();
    glPopMatrix();
}
void _head::draw_line(){
    glPushMatrix();
    changeSemi();
    Semi.draw_line();
    glPopMatrix();

    glPushMatrix();
    changeEsferaDcha();
    Esfera.draw_line();
    glPopMatrix();

    glPushMatrix();
    changeEsferaIzda();
    Esfera.draw_line();
    glPopMatrix();

    glPushMatrix();
    changeAntenaDcha();
    Antena.draw_line();
    glPopMatrix();

    glPushMatrix();
    changeAntenaIzda();
    Antena.draw_line();
    glPopMatrix();
}
void _head::draw_fill(){
    glPushMatrix();
    changeSemi();
    Semi.draw_fill();
    glPopMatrix();

    glPushMatrix();
    changeEsferaDcha();
    Esfera.draw_fill();
    glPopMatrix();

    glPushMatrix();
    changeEsferaIzda();
    Esfera.draw_fill();
    glPopMatrix();

    glPushMatrix();
    changeAntenaDcha();
    Antena.draw_fill();
    glPopMatrix();

    glPushMatrix();
    changeAntenaIzda();
    Antena.draw_fill();
    glPopMatrix();
}
void _head::draw_chess(){
    glPushMatrix();
    changeSemi();
    Semi.draw_chess();
    glPopMatrix();

    glPushMatrix();
    changeEsferaDcha();
    Esfera.draw_chess();
    glPopMatrix();

    glPushMatrix();
    changeEsferaIzda();
    Esfera.draw_chess();
    glPopMatrix();

    glPushMatrix();
    changeAntenaDcha();
    Antena.draw_chess();
    glPopMatrix();

    glPushMatrix();
    changeAntenaIzda();
    Antena.draw_chess();
    glPopMatrix();
}

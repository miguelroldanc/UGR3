#ifndef ANTENA_H
#define ANTENA_H

#include "cilindro.h"
#include "semiesfera.h"

class _antena
{
public:
    _semiesfera Semi;
    _cilindro Cilindro;

    void changeCilindro();
    void changeSemi();

    void draw_point();
    void draw_line();
    void draw_fill();
    void draw_chess();
};

#endif // ANTENA_H

#include "luz.h"

luz::luz():angulo_x(0),angulo_y(0),angulo_z(0),angulo_w(0),distancia(50.0){}

void luz::encenderLuz1(){
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    GLfloat pos[] = {0.0,0.0,1.0,0};
    glPushMatrix();
        glRotatef(angulo_w,0,1,0);
        glLightfv(GL_LIGHT0,GL_POSITION,pos);
    glPopMatrix();
}

void luz::encenderLuz2(){
    GLfloat luz_ambiente[] = {1.0, 0.0, 1.0, 1.0};
    glLightfv(GL_LIGHT1, GL_DIFFUSE, luz_ambiente);

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT1);

    GLfloat pos[] = {distancia, distancia, distancia, 1.0};
    glPushMatrix();
        glRotatef(angulo_z,0,0,1);
        glRotatef(angulo_x,1,0,0);
        glRotatef(angulo_y,0,1,0);
        glLightfv(GL_LIGHT1,GL_POSITION,pos);
    glPopMatrix();
}

void luz::apagarLuz1(){
    glDisable(GL_LIGHT0);
}

void luz::apagarLuz2(){
    glDisable(GL_LIGHT1);
}

void luz::apagarLuces(){
    apagarLuz1();
    apagarLuz2();
    glDisable(GL_LIGHTING);
}

void luz::moverLuz_x(){
    angulo_x = (angulo_x < 360)? angulo_x+10 : (angulo_x + 10 - 360);
}

void luz::moverLuz_y(){
    angulo_y = (angulo_y < 360)? angulo_y+10 : (angulo_y + 10 - 360);
}

void luz::moverLuz_z(){
    angulo_z = (angulo_z < 360)? angulo_z+10 : (angulo_z + 10 - 360);
}

void luz::moverLuz(){
    angulo_w = (angulo_w < 360)? angulo_w+10 : (angulo_w + 10 - 360);
}

void luz::aumentarDistancia(){
    distancia += 5;
}

void luz::disminuirDistancia(){
    distancia -= 5;
}

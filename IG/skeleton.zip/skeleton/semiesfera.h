#ifndef SEMIESFERA_H
#define SEMIESFERA_H
#include "revolution.h"

class _semiesfera : public revolution
{
public:
    _semiesfera(float Size=1.0, unsigned int n_caras=50, unsigned int vertices_perfil=10);
    void calcular_normales_vertices();
};

#endif // SEMIESFERA_H

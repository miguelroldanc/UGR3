#include "elbow.h"

void _elbow::changeFore(){
    glTranslatef(0,-1,0);
}

void _elbow::draw_point(){
    Esfera.draw_point();

    glPushMatrix();
    moveLittle();
    changeFore();
    Antebrazo.draw_point();
    glPopMatrix();
}
void _elbow::draw_line(){
    Esfera.draw_line();

    glPushMatrix();
    moveLittle();
    changeFore();
    Antebrazo.draw_line();
    glPopMatrix();
}
void _elbow::draw_fill(){
    Esfera.draw_fill();

    glPushMatrix();
    moveLittle();
    changeFore();
    Antebrazo.draw_fill();
    glPopMatrix();
}
void _elbow::draw_chess(){
    Esfera.draw_chess();

    glPushMatrix();
    moveLittle();
    changeFore();
    Antebrazo.draw_chess();
    glPopMatrix();
}

void _elbow::moveLittle(){
    glScalef(1,scaleLittle,1);
}

void _elbow::incrementarLittle(){
    scaleLittle += 0.2;
}
void _elbow::decrementarLittle(){
    scaleLittle -= 0.2;
}

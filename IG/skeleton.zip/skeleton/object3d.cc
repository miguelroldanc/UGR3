/*! \file
 * Copyright Domingo Martín Perandres
 * email: dmartin@ugr.es
 * web: http://calipso.ugr.es/dmartin
 * 2003-2019
 * GPL 3
 */


#include "object3d.h"
#include "textura.h"

using namespace _colors_ne;

/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

void _object3D::draw_line()
{
  glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
  glLineWidth(2);
  glBegin(GL_TRIANGLES);
  glColor3fv((GLfloat *) &BLACK);
  for (unsigned int i=0;i<Triangles.size();i++){
    glVertex3fv((GLfloat *) &Vertices[Triangles[i]._0]);
    glVertex3fv((GLfloat *) &Vertices[Triangles[i]._1]);
    glVertex3fv((GLfloat *) &Vertices[Triangles[i]._2]);
  }
  glEnd();
}


/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

void _object3D::draw_fill()
{
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    glBegin(GL_TRIANGLES);
    glColor3fv((GLfloat *) &BLUE);
    for (unsigned int i=0;i<Triangles.size();i++){
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._0]);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._1]);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._2]);
    }
    glEnd();
}


/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

void _object3D::draw_chess()
{
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    glBegin(GL_TRIANGLES);
    for (unsigned int i=0;i<Triangles.size();i++){
      //Each face of the surface has two colours
      if(i%2 == 0) glColor3fv((GLfloat *) &MAGENTA);
      else glColor3fv((GLfloat *) &CYAN);

      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._0]);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._1]);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._2]);
    }
    glEnd();
}


/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

void _object3D::draw_flat(){
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    glShadeModel(GL_FLAT);
    glBegin(GL_TRIANGLES);
    for (unsigned int i=0;i<Triangles.size();i++){
      glNormal3f((GLfloat)Normales[i]._0, (GLfloat)Normales[i]._1, (GLfloat)Normales[i]._2);

      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._0]);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._1]);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._2]);
    }
    glEnd();

}


/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

void _object3D::draw_smooth(){
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    glShadeModel(GL_SMOOTH);
    glBegin(GL_TRIANGLES);
    for (unsigned int i=0;i<Triangles.size();i++){
      glNormal3f((GLfloat)Normales_Vertex[Triangles[i]._0]._0,(GLfloat)Normales_Vertex[Triangles[i]._0]._1,(GLfloat)Normales_Vertex[Triangles[i]._0]._2);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._0]);

      glNormal3f((GLfloat)Normales_Vertex[Triangles[i]._1]._0,(GLfloat)Normales_Vertex[Triangles[i]._1]._1,(GLfloat)Normales_Vertex[Triangles[i]._1]._2);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._1]);

      glNormal3f((GLfloat)Normales_Vertex[Triangles[i]._2]._0,(GLfloat)Normales_Vertex[Triangles[i]._2]._1,(GLfloat)Normales_Vertex[Triangles[i]._2]._2);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._2]);
    }
    glEnd();

}

/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

void _object3D::draw_fill_textura(){
    parametros_textura();

    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    glBegin(GL_TRIANGLES);
    for (unsigned int i=0;i<Triangles.size();i++){
      glTexCoord2fv((GLfloat *) &Texturas[Triangles[i]._0]);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._0]);
      glTexCoord2fv((GLfloat *) &Texturas[Triangles[i]._1]);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._1]);
      glTexCoord2fv((GLfloat *) &Texturas[Triangles[i]._2]);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._2]);
    }
    glEnd();
    glDisable(GL_TEXTURE_2D);
}

/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

void _object3D::draw_flat_textura(){
    parametros_textura();

    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    glShadeModel(GL_FLAT);
    glBegin(GL_TRIANGLES);
    for (unsigned int i=0;i<Triangles.size();i++){
      glNormal3f((GLfloat)Normales[i]._0, (GLfloat)Normales[i]._1, (GLfloat)Normales[i]._2);

      glTexCoord2fv((GLfloat *) &Texturas[Triangles[i]._0]);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._0]);
      glTexCoord2fv((GLfloat *) &Texturas[Triangles[i]._1]);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._1]);
      glTexCoord2fv((GLfloat *) &Texturas[Triangles[i]._2]);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._2]);
    }
    glEnd();
    glDisable(GL_TEXTURE_2D);
}

/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

void _object3D::draw_smooth_textura(){
    parametros_textura();

    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    glShadeModel(GL_SMOOTH);
    glBegin(GL_TRIANGLES);
    for (unsigned int i=0;i<Triangles.size();i++){
      glNormal3f((GLfloat)Normales_Vertex[Triangles[i]._0]._0,(GLfloat)Normales_Vertex[Triangles[i]._0]._1,(GLfloat)Normales_Vertex[Triangles[i]._0]._2);
      glTexCoord2fv((GLfloat *) &Texturas[Triangles[i]._0]);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._0]);

      glNormal3f((GLfloat)Normales_Vertex[Triangles[i]._1]._0,(GLfloat)Normales_Vertex[Triangles[i]._1]._1,(GLfloat)Normales_Vertex[Triangles[i]._1]._2);
      glTexCoord2fv((GLfloat *) &Texturas[Triangles[i]._1]);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._1]);

      glNormal3f((GLfloat)Normales_Vertex[Triangles[i]._2]._0,(GLfloat)Normales_Vertex[Triangles[i]._2]._1,(GLfloat)Normales_Vertex[Triangles[i]._2]._2);
      glTexCoord2fv((GLfloat *) &Texturas[Triangles[i]._2]);
      glVertex3fv((GLfloat *) &Vertices[Triangles[i]._2]);
    }
    glEnd();
    glDisable(GL_TEXTURE_2D);
}

/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

void _object3D::parametros_textura(){
    // Code to control de application of the texture
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

    // Code to pass the image to OpenGL to form a texture 2D
    glTexImage2D(GL_TEXTURE_2D, 0, 3, this->Imagen.width(), this->Imagen.height(), 0, GL_RGB, GL_UNSIGNED_BYTE, this->Imagen.bits());

    glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_DECAL);
}

/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

void _object3D::calcular_normales(){
    unsigned long total_triangulos = Triangles.size();
    _vertex3f A, B; // A= P1 - P0****B= P2 - P0
    Normales.resize(total_triangulos);

    for(unsigned long i=0;i < total_triangulos;++i){
        A._0 = Vertices[Triangles[i]._1]._0 - Vertices[Triangles[i]._0]._0;
        A._1 = Vertices[Triangles[i]._1]._1 - Vertices[Triangles[i]._0]._1;
        A._2 = Vertices[Triangles[i]._1]._2 - Vertices[Triangles[i]._0]._2;
        B._0 = Vertices[Triangles[i]._2]._0 - Vertices[Triangles[i]._0]._0;
        B._1 = Vertices[Triangles[i]._2]._1 - Vertices[Triangles[i]._0]._1;
        B._2 = Vertices[Triangles[i]._2]._2 - Vertices[Triangles[i]._0]._2;

        A = A.cross_product(B);
        A = A.normalize();

        Normales[i] = A;
    }
}


/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

void _object3D::calcular_normales_vertices(){
    unsigned long total_vertices, total_triangulos;
    total_vertices = Vertices.size();
    total_triangulos = Triangles.size();

    Normales_Vertex.resize(total_vertices);

    for(unsigned long j=0;j < total_triangulos;++j){
        Normales_Vertex[Triangles[j]._0] += Normales[j];
        Normales_Vertex[Triangles[j]._1] += Normales[j];
        Normales_Vertex[Triangles[j]._2] += Normales[j];
    }

    for(unsigned long i=0;i < total_vertices;++i){
        Normales_Vertex[i] = Normales_Vertex[i].normalize();
    }
}


/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

void _object3D::utilizarMaterial1(){
    // jade
    _vertex4f ambiental = {0.135, 0.225, 0.1575, 1.0};
    _vertex4f diffuso = {0.54, 0.89, 0.63, 1.0};
    _vertex4f especular = {0.316228, 0.316228, 0.316228, 1.0};
    float shinnines = 0.1;

    textura text(ambiental, diffuso, especular, shinnines);
    text.usarTextura();
}


/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

void _object3D::utilizarMaterial2(){
    // laton
    _vertex4f ambiental = {0.329412, 0.223529, 0.027451, 1.0};
    _vertex4f diffuso = {0.780392, 0.568627, 0.113725, 1.0};
    _vertex4f especular = {0.992157, 0.941176, 0.807843, 1.0};
    float shinnines = 0.21794872;

    textura text(ambiental, diffuso, especular, shinnines);
    text.usarTextura();
}


/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

void _object3D::utilizarMaterial3(){
    // plata
    _vertex4f ambiental = {0.19225, 0.19225, 0.19225, 1.0};
    _vertex4f diffuso = {0.50754, 0.50754, 0.50754, 1.0};
    _vertex4f especular = {0.508273, 0.508273, 0.508273, 1.0};
    float shinnines = 0.4;

    textura text(ambiental, diffuso, especular, shinnines);
    text.usarTextura();
}

#include "objeto_ply.h"

_objeto_ply::_objeto_ply()
{

}

bool _objeto_ply::read_ply(){
    _file_ply File_ply;

    if(File_ply.open("/home/miguel/Documents/3o/IG/modelos_ply/huge_bunny.ply")){
        File_ply.read(Vertices, Triangles);
        std::cout << "File read correctly" << std::endl;
        this->calcular_normales();
        this->calcular_normales_vertices();

        return true;
    }else{
        std::cout << "File cannot be opened" << std::endl;
        return false;
    }
}

#ifndef ESFERA_H
#define ESFERA_H

#include "revolution.h"

class _esfera : public revolution
{
public:
    _esfera(float Size=1.0, unsigned int n_caras=50, unsigned int vertices_perfil=20);
    void calcular_normales_vertices();
};

#endif // ESFERA_H

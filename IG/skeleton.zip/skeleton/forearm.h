#ifndef FOREARM_H
#define FOREARM_H

#include "cilindro.h"
#include "semiesfera.h"

class _forearm
{
public:
    _cilindro Cilindro;
    _semiesfera Semi;

    void changeBotSemi();

    void draw_point();
    void draw_line();
    void draw_fill();
    void draw_chess();
};

#endif // FOREARM_H

#include "body.h"

void _body::changeBody(){
    glScalef(10,10,10);
}
void _body::changeHead(){
    glTranslatef(0,6,0);
}
void _body::changeLeftArm(){
    glTranslatef(-5.5,1,0);
    glScalef(2,2,2);
}
void _body::changeRightArm(){
    glTranslatef(5.5,1,0);
    glRotatef(180,0,1,0);
    glScalef(2,2,2);
}
void _body::changeLeftLeg(){
    glTranslatef(-2.5,-6,0);
    glScalef(2,2,2);
}
void _body::changeRightLeg(){
    glTranslatef(2.5,-6,0);
    glScalef(2,2,2);
}
void _body::draw_point(){
    glPushMatrix();
    changeBody();
    Cilindro.draw_point();
    glPopMatrix();

    glPushMatrix();
    changeHead();
    moveHead();
    Cabeza.draw_point();
    glPopMatrix();

    glPushMatrix();
    changeLeftArm();
    moveArms();
    Brazo.draw_point();
    glPopMatrix();

    glPushMatrix();
    changeRightArm();
    moveArms();
    Brazo.draw_point();
    glPopMatrix();

    glPushMatrix();
    changeLeftLeg();
    moveLeftLeg();
    Pierna.draw_point();
    glPopMatrix();

    glPushMatrix();
    changeRightLeg();
    moveRightLeg();
    Pierna.draw_point();
    glPopMatrix();
}
void _body::draw_line(){
    glPushMatrix();
    changeBody();
    Cilindro.draw_line();
    glPopMatrix();

    glPushMatrix();
    changeHead();
    moveHead();
    Cabeza.draw_line();
    glPopMatrix();

    glPushMatrix();
    changeLeftArm();
    moveArms();
    Brazo.draw_line();
    glPopMatrix();

    glPushMatrix();
    changeRightArm();
    moveArms();
    Brazo.draw_line();
    glPopMatrix();

    glPushMatrix();
    changeLeftLeg();
    moveLeftLeg();
    Pierna.draw_line();
    glPopMatrix();

    glPushMatrix();
    changeRightLeg();
    moveRightLeg();
    Pierna.draw_line();
    glPopMatrix();
}
void _body::draw_fill(){
    glPushMatrix();
    changeBody();
    Cilindro.draw_fill();
    glPopMatrix();

    glPushMatrix();
    changeHead();
    moveHead();
    Cabeza.draw_fill();
    glPopMatrix();

    glPushMatrix();
    changeLeftArm();
    moveArms();
    Brazo.draw_fill();
    glPopMatrix();

    glPushMatrix();
    changeRightArm();
    moveArms();
    Brazo.draw_fill();
    glPopMatrix();

    glPushMatrix();
    changeLeftLeg();
    moveLeftLeg();
    Pierna.draw_fill();
    glPopMatrix();

    glPushMatrix();
    changeRightLeg();
    moveRightLeg();
    Pierna.draw_fill();
    glPopMatrix();
}
void _body::draw_chess(){
    glPushMatrix();
    changeBody();
    Cilindro.draw_chess();
    glPopMatrix();

    glPushMatrix();
    changeHead();
    moveHead();
    Cabeza.draw_chess();
    glPopMatrix();

    glPushMatrix();
    changeLeftArm();
    moveArms();
    Brazo.draw_chess();
    glPopMatrix();

    glPushMatrix();
    changeRightArm();
    moveArms();
    Brazo.draw_chess();
    glPopMatrix();

    glPushMatrix();
    changeLeftLeg();
    moveLeftLeg();
    Pierna.draw_chess();
    glPopMatrix();

    glPushMatrix();
    changeRightLeg();
    moveRightLeg();
    Pierna.draw_chess();
    glPopMatrix();
}
void _body::moveRightLeg(){
    glRotatef(rotLeg,1,0,0);
}
void _body::moveLeftLeg(){
    glRotatef(-rotLeg,1,0,0);
}
void _body::moveArms(){
    glRotatef(rotBrazo,1,0,0);
}
void _body::moveHead(){
    glTranslatef(0,transCabeza,0);
}
void _body::incrementarMove(){
    rotLeg += ratioLeg;
}
void _body::decrementarMove(){
    rotLeg -= ratioLeg;
}
void _body::incrementarArm(){
    rotBrazo += ratioArm;
}
void _body::decrementarArm(){
    rotBrazo -= ratioArm;
}
void _body::incrementarHead(){
    transCabeza += ratioCabeza;
}
void _body::decrementarHead(){
    transCabeza -= ratioCabeza;
}
void _body::acelerarArms(){
    ratioArm++;
}
void _body::decelerarArms(){
    ratioArm--;
}
void _body::acelerarLegs(){
    ratioLeg++;
}
void _body::decelerarLegs(){
    ratioLeg--;
}
void _body::acelerarHead(){
    ratioCabeza += 0.1;
}
void _body::decelerarHead(){
    ratioCabeza -= 0.1;
}

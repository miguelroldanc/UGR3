#ifndef TABLERO_H
#define TABLERO_H

#include "cube.h"

class _tablero
{
public:
    _cube Cubo;
    void transformar();
    void draw_fill();
};

#endif // TABLERO_H

/*! \file
 * Copyright Domingo Martín Perandres
 * email: dmartin@ugr.es
 * web: http://calipso.ugr.es/dmartin
 * 2003-2019
 * GPL 3
 */


#ifndef OBJECT3D_H
#define OBJECT3D_H

#include "basic_object3d.h"
#include <cmath>
#include <QImage>

/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

class _object3D:public _basic_object3D
{
  public:
  vector<_vertex3ui> Triangles;
  vector<_vertex3f> Normales;
  vector<_vertex3f> Normales_Vertex;
  vector<_vertex2f> Texturas; // Tiene el mismo tamaño que vertices
  QImage Imagen;

  void draw_line();
  void draw_fill();
  void draw_chess();
  void draw_flat();
  void draw_smooth();
  void draw_fill_textura();
  void draw_flat_textura();
  void draw_smooth_textura();
  inline void parametros_textura();

  void calcular_normales();
  void calcular_normales_vertices();

  void utilizarMaterial1();
  void utilizarMaterial2();
  void utilizarMaterial3();
};

#endif // OBJECT3D_H

#include "arm.h"

void _arm::changeAnte(){
    glTranslatef(0,1,0);
    glRotatef(180,1,0,0);
}
void _arm::moveElbow(){
    glRotatef(gradeElbow,1,0,0);
}
void _arm::incrementarElbow(){
    gradeElbow +=ratioCodo;
}
void _arm::decrementarElbow(){
    gradeElbow -= ratioCodo;
}
void _arm::acelerarElbow(){
    ratioCodo++;
}
void _arm::decelerarElbow(){
    ratioCodo--;
}
void _arm::draw_point(){
    glPushMatrix();
    changeAnte();
    Ante.draw_point();
    glPopMatrix();

    glPushMatrix();
    moveElbow();
    Codo.draw_point();
    glPopMatrix();
}
void _arm::draw_line(){
    glPushMatrix();
    changeAnte();
    Ante.draw_line();
    glPopMatrix();

    glPushMatrix();
    moveElbow();
    Codo.draw_line();
    glPopMatrix();
}
void _arm::draw_fill(){
    glPushMatrix();
    changeAnte();
    Ante.draw_fill();
    glPopMatrix();

    glPushMatrix();
    moveElbow();
    Codo.draw_fill();
    glPopMatrix();
}
void _arm::draw_chess(){
    glPushMatrix();
    changeAnte();
    Ante.draw_chess();
    glPopMatrix();

    glPushMatrix();
    moveElbow();
    Codo.draw_chess();
    glPopMatrix();
}

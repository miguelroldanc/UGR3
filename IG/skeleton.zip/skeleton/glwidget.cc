/*! \file
 * Copyright Domingo Martín Perandres
 * email: dmartin@ugr.es
 * web: http://calipso.ugr.es/dmartin
 * 2003-2019
 * GPL 3
 */


#include "glwidget.h"
#include "window.h"

using namespace std;
using namespace _gl_widget_ne;
using namespace _colors_ne;


/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

_gl_widget::_gl_widget(_window *Window1):Window(Window1)
{
  setMinimumSize(300, 300);
  setFocusPolicy(Qt::StrongFocus);

  //Read ply
  Ply.read_ply();

  // Code to define the Qtimer for the animation
  timer = new QTimer(this);
  timer->setInterval(0);
  connect(timer, SIGNAL(timeout()),this,SLOT(idle()));

  // Animacion
  animado = false;
  dir_animado = true;
  brazo_animado = true;
  cabeza_animado = true;

  Cuerpo.rotLeg = 0;
  Cuerpo.Brazo.Brazo.gradeElbow = 0;
  Cuerpo.rotBrazo = 0;
  Cuerpo.transCabeza = 0;

  Cuerpo.ratioArm = INIT_RATIO;
  Cuerpo.ratioLeg = INIT_RATIO;
  Cuerpo.Brazo.Brazo.ratioCodo = INIT_RATIO;
  Cuerpo.ratioCabeza = INIT_TRANS;

  activarLuz1 = false;
  activarLuz2 = false;
  material = 0;
}


/*****************************************************************************//**
 * Evento tecla pulsada
 *
 *
 *
 *****************************************************************************/

void _gl_widget::keyPressEvent(QKeyEvent *Keyevent)
{
  switch(Keyevent->key()){
  case Qt::Key_1:Object=OBJECT_TETRAHEDRON;break;
  case Qt::Key_2:Object=OBJECT_CUBE;break;
  case Qt::Key_3:Object=OBJECT_CONO;break;
  case Qt::Key_4:Object=OBJECT_CILINDRO;break;
  case Qt::Key_5:Object=OBJECT_ESFERA;break;
  case Qt::Key_6:Object=OBJETO_PLY;break;
  case Qt::Key_7:Object=OBJECT_BODY;break;
  case Qt::Key_8:Object=OBJECT_PLY_REVOLUTION;break;
  case Qt::Key_9:Object=OBJECT_TABLERO;break;
  case Qt::Key_A:{
      if(!animado){
          timer->start();
          animado = true;
      }else{
          timer->stop();
          animado = false;
      }
  }break;
  case Qt::Key_Q:{
      if(Cuerpo.rotLeg < TOPE_ROT) Cuerpo.incrementarMove();
  }break;
  case Qt::Key_W:{
      if(Cuerpo.rotLeg > -TOPE_ROT) Cuerpo.decrementarMove();
  }break;
  case Qt::Key_S:{
      if(Cuerpo.transCabeza < MAX_TRANSLATION) Cuerpo.incrementarHead();
  }break;
  case Qt::Key_D:{
      if(Cuerpo.transCabeza > -MAX_TRANSLATION) Cuerpo.decrementarHead();
  }break;
  case Qt::Key_Z:{
      if(Cuerpo.rotBrazo < TOPE_ROT) Cuerpo.incrementarArm();
  }break;
  case Qt::Key_X:{
      if(Cuerpo.rotBrazo > -TOPE_ROT) Cuerpo.decrementarArm();
  }break;
  case Qt::Key_E:{
      if(Cuerpo.ratioLeg < TOPE_SPEED) Cuerpo.acelerarLegs();
  }break;
  case Qt::Key_R:{
      if(Cuerpo.ratioLeg > MIN_SPEED) Cuerpo.decelerarLegs();
  }break;
  case Qt::Key_T:{
      if(Cuerpo.ratioCabeza < TOPE_TRANS) Cuerpo.acelerarHead();
  }break;
  case Qt::Key_Y:{
      if(Cuerpo.ratioCabeza > MIN_TRANS) Cuerpo.decelerarHead();
  }break;
  case Qt::Key_U:{
      if(Cuerpo.ratioArm < TOPE_SPEED) Cuerpo.acelerarArms();
  }break;
  case Qt::Key_I:{
      if(Cuerpo.ratioArm > MIN_SPEED) Cuerpo.decelerarArms();
  }break;

  case Qt::Key_J:activarLuz1=!activarLuz1;break;
  case Qt::Key_K:activarLuz2=!activarLuz2;break;
  case Qt::Key_M:material = (material+1)%3;break;

  case Qt::Key_P:Draw_point=!Draw_point;break;
  case Qt::Key_L:Draw_line=!Draw_line;break;
  case Qt::Key_F:Draw_fill=!Draw_fill;break;
  case Qt::Key_F1:{
      if(Draw_fill == true){
          Draw_chess = false;
          Draw_flat = false;
          Draw_smooth = false;
      }

  }break;
  case Qt::Key_F2:Draw_chess=!Draw_chess;break;
  case Qt::Key_F3:Draw_flat=!Draw_flat;break;
  case Qt::Key_F4:Draw_smooth=!Draw_smooth;break;

  case Qt::Key_Left:Observer_angle_y-=ANGLE_STEP;break;
  case Qt::Key_Right:Observer_angle_y+=ANGLE_STEP;break;
  case Qt::Key_Up:Observer_angle_x-=ANGLE_STEP;break;
  case Qt::Key_Down:Observer_angle_x+=ANGLE_STEP;break;
  case Qt::Key_PageUp:Observer_distance*=1.2;break;
  case Qt::Key_PageDown:Observer_distance/=1.2;break;
  }

  update();
}


/*****************************************************************************//**
 * Limpiar ventana
 *
 *
 *
 *****************************************************************************/

void _gl_widget::clear_window()
{
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
}



/*****************************************************************************//**
 * Funcion para definir la transformación de proyeccion
 *
 *
 *
 *****************************************************************************/

void _gl_widget::change_projection()
{

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();

  // formato(x_minimo,x_maximo, y_minimo, y_maximo,Front_plane, plano_traser)
  // Front_plane>0  Back_plane>PlanoDelantero)
  // Proyeccion paralela
  glFrustum(X_MIN*ratio,X_MAX*ratio,Y_MIN,Y_MAX,FRONT_PLANE_PERSPECTIVE,BACK_PLANE_PERSPECTIVE);
  // Proyeccion ortogonal
  // glOrtho(X_MIN, X_MAX, Y_MIN, Y_MAX, FRONT_PLANE_PERSPECTIVE, BACK_PLANE_PERSPECTIVE);
}



/*****************************************************************************//**
 * Funcion para definir la transformación de vista (posicionar la camara)
 *
 *
 *
 *****************************************************************************/

void _gl_widget::change_observer()
{
  // posicion del observador
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glTranslatef(0,0,-Observer_distance);
  glRotatef(Observer_angle_x,1,0,0);
  glRotatef(Observer_angle_y,0,1,0);
}


/*****************************************************************************//**
 * Funcion que dibuja los objetos
 *
 *
 *
 *****************************************************************************/

void _gl_widget::draw_objects()
{
  glMatrixMode(GL_MODELVIEW);

  Axis.draw_line();

  if(material == 0) Cube.utilizarMaterial1();
  else if(material == 1) Cube.utilizarMaterial2();
  else if(material == 2) Cube.utilizarMaterial3();

  if (Draw_point){
    switch (Object){
    case OBJECT_TETRAHEDRON:Tetrahedron.draw_point();break;
    case OBJECT_CUBE:Cube.draw_point();break;
    case OBJECT_CONO:Cono.draw_point();break;
    case OBJECT_CILINDRO:Cilindro.draw_point();break;
    case OBJECT_ESFERA:Esfera.draw_point();break;
    case OBJETO_PLY:Ply.draw_point();break;
    case OBJECT_PLY_REVOLUTION:Ply_revolution.draw_point();break;
    // case OBJECT_MESFERA:Semiesfera.draw_point();break;
    case OBJECT_BODY:Cuerpo.draw_point();break;
    default:break;
    }
  }

  if (Draw_line){
    switch (Object){
    case OBJECT_TETRAHEDRON:Tetrahedron.draw_line();break;
    case OBJECT_CUBE:Cube.draw_line();break;
    case OBJECT_CONO:Cono.draw_line();break;
    case OBJECT_CILINDRO:Cilindro.draw_line();break;
    case OBJECT_ESFERA:Esfera.draw_line();break;
    case OBJETO_PLY:Ply.draw_line();break;
    case OBJECT_PLY_REVOLUTION:Ply_revolution.draw_line();break;
    // case OBJECT_MESFERA:Semiesfera.draw_line();break;
    case OBJECT_BODY:Cuerpo.draw_line();break;
    default:break;
    }
  }

  if (Draw_fill){
      if(Draw_smooth){
          switch (Object){
          case OBJECT_TETRAHEDRON:Tetrahedron.draw_smooth();break;
          case OBJECT_CUBE:Cube.draw_smooth();break;
          case OBJECT_CONO:Cono.draw_smooth();break;
          case OBJECT_CILINDRO:Cilindro.draw_smooth();break;
          case OBJECT_ESFERA:Esfera.draw_smooth();break;
          case OBJETO_PLY:Ply.draw_smooth();break;
          case OBJECT_PLY_REVOLUTION:Ply_revolution.draw_smooth();break;
          // case OBJECT_MESFERA:Semiesfera.draw_smooth();break;
          // case OBJECT_BODY:Cuerpo.draw_smooth();break;
          default:break;
          }
      }
      if(Draw_flat){

          switch (Object){
          case OBJECT_TETRAHEDRON:Tetrahedron.draw_flat();break;
          case OBJECT_CUBE:Cube.draw_flat();break;
          case OBJECT_CONO:Cono.draw_flat();break;
          case OBJECT_CILINDRO:Cilindro.draw_flat();break;
          case OBJECT_ESFERA:Esfera.draw_flat();break;
          case OBJETO_PLY:Ply.draw_flat();break;
          case OBJECT_PLY_REVOLUTION:Ply_revolution.draw_flat();break;
          // case OBJECT_MESFERA:Semiesfera.draw_flat();break;
          // case OBJECT_BODY:Cuerpo.draw_flat();break;
          default:break;
          }
      }
      if(Draw_chess){
          switch (Object){
          case OBJECT_TETRAHEDRON:Tetrahedron.draw_chess();break;
          case OBJECT_CUBE:Cube.draw_chess();break;
          case OBJECT_CONO:Cono.draw_chess();break;
          case OBJECT_CILINDRO:Cilindro.draw_chess();break;
          case OBJECT_ESFERA:Esfera.draw_chess();break;
          case OBJETO_PLY:Ply.draw_chess();break;
          case OBJECT_PLY_REVOLUTION:Ply_revolution.draw_chess();break;
          // case OBJECT_MESFERA:Semiesfera.draw_chess();break;
          case OBJECT_BODY:Cuerpo.draw_chess();break;
          default:break;
          }
      }
      if(Draw_fill){
          switch (Object){
          case OBJECT_TETRAHEDRON:Tetrahedron.draw_fill();break;
          case OBJECT_CUBE:Cube.draw_fill();break;
          case OBJECT_CONO:Cono.draw_fill();break;
          case OBJECT_CILINDRO:Cilindro.draw_fill();break;
          case OBJECT_ESFERA:Esfera.draw_fill();break;
          case OBJETO_PLY:Ply.draw_fill();break;
          case OBJECT_PLY_REVOLUTION:Ply_revolution.draw_fill();break;
          // case OBJECT_MESFERA:Semiesfera.draw_fill();break;
          case OBJECT_BODY:Cuerpo.draw_fill();break;
          case OBJECT_TABLERO:{
              cargarImagen(tablero.Cubo.Imagen);
              tablero.draw_fill();
          }break;
          default:break;
          }
      }
  }
}

/*****************************************************************************//**
 * Evento idle
 *
 *
 *
 ******************************************************************************/
void _gl_widget::idle(){
    if(dir_animado){
        Cuerpo.incrementarMove();
        if(Cuerpo.rotLeg > TOPE_ROT){
            dir_animado = false;
        }
    }else{
        Cuerpo.decrementarMove();
        if(Cuerpo.rotLeg < -TOPE_ROT){
            dir_animado = true;
        }
    }

    if(brazo_animado){
        Cuerpo.incrementarArm();
        Cuerpo.Brazo.Brazo.incrementarElbow();
        Cuerpo.Brazo.Brazo.Codo.incrementarLittle();

        if(Cuerpo.Brazo.Brazo.gradeElbow > TOPE_ROT)
            brazo_animado = false;
    }else{
        Cuerpo.decrementarArm();
        Cuerpo.Brazo.Brazo.decrementarElbow();
        Cuerpo.Brazo.Brazo.Codo.decrementarLittle();

        if(Cuerpo.Brazo.Brazo.gradeElbow < -TOPE_ROT)
            brazo_animado = true;
    }

    if(cabeza_animado){
        Cuerpo.incrementarHead();
        if(Cuerpo.transCabeza > MAX_TRANSLATION)
            cabeza_animado = false;
    }else{
        Cuerpo.decrementarHead();
        if(Cuerpo.transCabeza < -MAX_TRANSLATION)
            cabeza_animado = true;
    }

    if(activarLuz2){
        lighter.moverLuz_y();
    }


    update();
}

/*****************************************************************************//**
 * Evento de dibujado
 *
 *
 *
 *****************************************************************************/

void _gl_widget::paintGL()
{
  clear_window();

  if(activarLuz1)
    lighter.encenderLuz1();
  else
    lighter.apagarLuz1();
  if(activarLuz2)
    lighter.encenderLuz2();
  else
    lighter.apagarLuz2();

  if(!activarLuz1 && !activarLuz2) lighter.apagarLuces();

  change_projection();
  change_observer();
  draw_objects();
}


/*****************************************************************************//**
 * Evento de cambio de tamaño de la ventana
 *
 *
 *
 *****************************************************************************/

void _gl_widget::resizeGL(int Width1, int Height1)
{
  glViewport(0,0,Width1,Height1);
  ratio = (float)Width1/(float)Height1;
}


/*****************************************************************************//**
 * Cargar una imagen
 *
 *
 *
 *****************************************************************************/

void _gl_widget::cargarImagen(QImage &Imagen){
    // Code for reading an image
        QString File_name("/home/miguel/Documents/3o/IG/chessboard.png");
        QImageReader Reader(File_name);
        Reader.setAutoTransform(true);
        Imagen = Reader.read();
        if(Imagen.isNull()){
            QMessageBox::information(this, QGuiApplication::applicationDisplayName(), tr("Cannot load %1").arg(QDir::toNativeSeparators(File_name)));
            exit(-1);
        }

        Imagen = Imagen.mirrored();
        Imagen = Imagen.convertToFormat(QImage::Format_RGB888);
}


/*****************************************************************************//**
 * Inicialización de OpenGL
 *
 *
 *
 *****************************************************************************/

void _gl_widget::initializeGL()
{
  const GLubyte* strm;

  strm = glGetString(GL_VENDOR);
  std::cerr << "Vendor: " << strm << "\n";
  strm = glGetString(GL_RENDERER);
  std::cerr << "Renderer: " << strm << "\n";
  strm = glGetString(GL_VERSION);
  std::cerr << "OpenGL Version: " << strm << "\n";

  if (strm[0] == '1'){
    std::cerr << "Only OpenGL 1.X supported!\n";
    exit(-1);
  }

  strm = glGetString(GL_SHADING_LANGUAGE_VERSION);
  std::cerr << "GLSL Version: " << strm << "\n";

  int Max_texture_size=0;
  glGetIntegerv(GL_MAX_TEXTURE_SIZE, &Max_texture_size);
  std::cerr << "Max texture size: " << Max_texture_size << "\n";

  glClearColor(1.0,1.0,1.0,1.0);
  glEnable(GL_DEPTH_TEST);;

  Observer_angle_x=0;
  Observer_angle_y=0;
  Observer_distance=DEFAULT_DISTANCE;

  Draw_point=false;
  Draw_line=true;
  Draw_fill=false;
  Draw_chess=false;
}

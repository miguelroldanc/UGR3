#ifndef ELBOW_H
#define ELBOW_H

#include "forearm.h"
#include "esfera.h"

class _elbow
{
public:
    _forearm Antebrazo;
    _esfera Esfera;
    float scaleLittle=1.0;

    void changeFore();
    void moveLittle();
    void incrementarLittle();
    void decrementarLittle();

    void draw_point();
    void draw_line();
    void draw_fill();
    void draw_chess();
};

#endif // ELBOW_H

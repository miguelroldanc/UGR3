#ifndef LUZ_H
#define LUZ_H

#include <vector>
#include <GL/gl.h>
#include "colors.h"
#include "vertex.h"

class luz
{
private:
    float angulo_x, angulo_y, angulo_z, angulo_w, distancia;
public:
    luz();
    void moverLuz_x();
    void moverLuz_y();
    void moverLuz_z();
    void moverLuz();
    void aumentarDistancia();
    void disminuirDistancia();

    void encenderLuz1();
    void encenderLuz2();

    void apagarLuz1();
    void apagarLuz2();
    void apagarLuces();
};

#endif // LUZ_H

#include "leg.h"

void _leg::changeCyl(){
    glScalef(2,1.5,2);
}
void _leg::changeSemi(){
    glTranslatef(0,-0.75,0);
    glScalef(2,1,2);
}

void _leg::draw_point(){
    glPushMatrix();
    changeCyl();
    Cilindro.draw_point();
    glPopMatrix();

    glPushMatrix();
    changeSemi();
    Semi.draw_point();
    glPopMatrix();
}
void _leg::draw_line(){
    glPushMatrix();
    changeCyl();
    Cilindro.draw_line();
    glPopMatrix();

    glPushMatrix();
    changeSemi();
    Semi.draw_line();
    glPopMatrix();
}
void _leg::draw_fill(){
    glPushMatrix();
    changeCyl();
    Cilindro.draw_fill();
    glPopMatrix();

    glPushMatrix();
    changeSemi();
    Semi.draw_fill();
    glPopMatrix();
}
void _leg::draw_chess(){
    glPushMatrix();
    changeCyl();
    Cilindro.draw_chess();
    glPopMatrix();

    glPushMatrix();
    changeSemi();
    Semi.draw_chess();
    glPopMatrix();
}

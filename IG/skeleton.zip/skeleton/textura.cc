#include "textura.h"

textura::textura(const _vertex4f &amb, const _vertex4f &diff, const _vertex4f spec, float shiny):ambient(amb),diffuse(diff),specular(spec),shininess(shiny){}

void textura::usarTextura(){
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
        glMaterialfv(GL_FRONT, GL_AMBIENT, (GLfloat *)&ambient);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, (GLfloat *)&diffuse);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, (GLfloat *)&specular);
        glMaterialf(GL_FRONT, GL_SHININESS, shininess*128.0);
    glPopMatrix();
}

#ifndef BODY_H
#define BODY_H

#include "bigarm.h"
#include "leg.h"
#include "cilindro.h"
#include "head.h"

class _body
{
public:
    _cilindro Cilindro;
    _bigarm Brazo;
    _head Cabeza;
    _leg Pierna;
    int rotLeg;
    int rotBrazo;
    float transCabeza;
    int ratioArm;
    int ratioLeg;
    float ratioCabeza;

    void changeHead();
    void changeLeftArm();
    void changeRightArm();
    void changeBody();
    void changeLeftLeg();
    void changeRightLeg();

    void moveRightLeg();
    void moveLeftLeg();
    void moveArms();
    void moveHead();
    void incrementarMove();
    void decrementarMove();
    void incrementarArm();
    void decrementarArm();
    void incrementarHead();
    void decrementarHead();
    void acelerarArms();
    void decelerarArms();
    void acelerarLegs();
    void decelerarLegs();
    void acelerarHead();
    void decelerarHead();

    void draw_point();
    void draw_line();
    void draw_fill();
    void draw_chess();
};

#endif // BODY_H

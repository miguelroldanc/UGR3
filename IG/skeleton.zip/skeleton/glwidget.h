/*! \file
 * Copyright Domingo Martín Perandres
 * email: dmartin@ugr.es
 * web: http://calipso.ugr.es/dmartin
 * 2003-2019
 * GPL 3
 */


#ifndef GLWIDGET_H
#define GLWIDGET_H

#include <GL/gl.h>
#include <QOpenGLWidget>
#include <QKeyEvent>
#include <QImageReader>
#include <iostream>
#include "vertex.h"
#include "colors.h"
#include "axis.h"
#include "tetrahedron.h"
#include "cube.h"
#include "cono.h"
#include "cilindro.h"
#include "objeto_ply.h"
#include "esfera.h"
#include "semiesfera.h"
#include "revolutionply.h"
#include "body.h"
#include <QTimer>
#include "luz.h"
#include "tablero.h"


namespace _gl_widget_ne {

  const float X_MIN=-.1;
  const float X_MAX=.1;
  const float Y_MIN=-.1;
  const float Y_MAX=.1;
  const float FRONT_PLANE_PERSPECTIVE=(X_MAX-X_MIN)/2;
  const float BACK_PLANE_PERSPECTIVE=1000;
  const float DEFAULT_DISTANCE=2;
  const float ANGLE_STEP=1;
  const int TOPE_ROT = 35;
  const int TOPE_SPEED = 10;
  const int MIN_SPEED = 1;
  const float TOPE_TRANS = 0.5;
  const float MIN_TRANS = 0.1;
  const int INIT_RATIO = 5;
  const float INIT_TRANS = 0.2;
  const float MAX_TRANSLATION = 0.9;

  typedef enum {MODE_DRAW_POINT,MODE_DRAW_LINE,MODE_DRAW_FILL,MODE_DRAW_CHESS} _mode_draw;
  typedef enum {OBJECT_TETRAHEDRON,OBJECT_CUBE, OBJECT_CONO, OBJETO_PLY, OBJECT_CILINDRO, OBJECT_ESFERA,
                OBJECT_PLY_REVOLUTION, OBJECT_MESFERA, OBJECT_BODY, OBJECT_TABLERO} _object;
}

class _window;


/*****************************************************************************//**
 *
 *
 *
 *****************************************************************************/

class _gl_widget : public QOpenGLWidget
{
Q_OBJECT
public:
  _gl_widget(_window *Window1);

  void clear_window();
  void change_projection();
  void change_observer();

  void draw_axis();
  void draw_objects();

  void cargarImagen(QImage &Imagen);

public slots:
  void idle();

protected:
  void resizeGL(int Width1, int Height1) Q_DECL_OVERRIDE;
  void paintGL() Q_DECL_OVERRIDE;
  void initializeGL() Q_DECL_OVERRIDE;
  void keyPressEvent(QKeyEvent *Keyevent) Q_DECL_OVERRIDE;


private:
  _window *Window;

  _axis Axis;
  _tetrahedron Tetrahedron;
  _cube Cube;
  _cono Cono;
  _cilindro Cilindro;
  _objeto_ply Ply;
  // _esfera Esfera = _esfera(1,4,25);
  _esfera Esfera;
  _semiesfera Semiesfera;
  _revolutionply Ply_revolution;

  _tablero tablero;

  // Mi figura
  _body Cuerpo;

  // Animacion
  QTimer *timer;
  bool animado;
  bool dir_animado;
  bool brazo_animado;
  bool cabeza_animado;

  //Iluminacion
  luz lighter;
  bool activarLuz1;
  bool activarLuz2;

  //Materiales y texturas
  unsigned long material;

  _gl_widget_ne::_object Object;

  bool Draw_point;
  bool Draw_line;
  bool Draw_fill;
  bool Draw_chess = false;
  bool Draw_flat = false;
  bool Draw_smooth = false;

  float Observer_angle_x;
  float Observer_angle_y;
  float Observer_distance;

  float ratio=1;
};

#endif

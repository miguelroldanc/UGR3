#ifndef HEAD_H
#define HEAD_H

#include "semiesfera.h"
#include "esfera.h"
#include "antena.h"

class _head
{
public:
    _semiesfera Semi;
    _esfera Esfera;
    _antena Antena;

    void changeSemi();
    void changeEsferaIzda();
    void changeEsferaDcha();
    void changeAntenaIzda();
    void changeAntenaDcha();

    void draw_point();
    void draw_line();
    void draw_fill();
    void draw_chess();
};

#endif // HEAD_H

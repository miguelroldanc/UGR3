#include "bigarm.h"

void _bigarm::changeArm(){
    glTranslatef(-0.5,-1,0);
}
void _bigarm::changeCilindro(){
    glRotatef(90,0,0,1);
}
void _bigarm::draw_point(){
    glPushMatrix();
    changeArm();
    Brazo.draw_point();
    glPopMatrix();

    glPushMatrix();
    changeCilindro();
    Cilindro.draw_point();
    glPopMatrix();
}
void _bigarm::draw_line(){
    glPushMatrix();
    changeArm();
    Brazo.draw_line();
    glPopMatrix();

    glPushMatrix();
    changeCilindro();
    Cilindro.draw_line();
    glPopMatrix();
}
void _bigarm::draw_fill(){
    glPushMatrix();
    changeArm();
    Brazo.draw_fill();
    glPopMatrix();

    glPushMatrix();
    changeCilindro();
    Cilindro.draw_fill();
    glPopMatrix();
}
void _bigarm::draw_chess(){
    glPushMatrix();
    changeArm();
    Brazo.draw_chess();
    glPopMatrix();

    glPushMatrix();
    changeCilindro();
    Cilindro.draw_chess();
    glPopMatrix();
}

#ifndef REVOLUTIONPLY_H
#define REVOLUTIONPLY_H
#include "revolution.h"
#include "file_ply_stl.h"

class _revolutionply: public revolution
{
public:
    _revolutionply(unsigned long n_caras=3, bool sentido=false);
};

#endif // REVOLUTIONPLY_H

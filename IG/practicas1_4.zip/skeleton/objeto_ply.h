#ifndef OBJETO_PLY_H
#define OBJETO_PLY_H

#include "object3d.h"
#include "file_ply_stl.h"

class _objeto_ply : public _object3D
{
public:
    _objeto_ply();
    bool read_ply();
};

#endif // OBJETO_PLY_H

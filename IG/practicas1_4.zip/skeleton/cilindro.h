#ifndef CILINDRO_H
#define CILINDRO_H

#include "revolution.h"

class _cilindro :public revolution
{
public:
    _cilindro(float Size=1.0, unsigned int n_caras=50);
};

#endif // CILINDRO_H

#include "cilindro.h"

_cilindro::_cilindro(float Size, unsigned int n_caras)
{
    Vertices.resize(4);
    Vertices[0] = _vertex3f(Size/2, Size/2, 0);
    Vertices[1] = _vertex3f(Size/2, -Size/2, 0);
    Vertices[2] = _vertex3f(0, Size/2, 0);
    Vertices[3] = _vertex3f(0, -Size/2, 0);

    revolucionarObjeto(Vertices, Triangles, n_caras, true);
    this->calcular_normales();
    this->calcular_normales_vertices();
}

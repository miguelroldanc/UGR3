#ifndef _CONO_H
#define _CONO_H
#include "revolution.h"

class _cono :public revolution
{
public:
    _cono(float Size=1.0, unsigned int n_caras = 50);
};

#endif // _CONO_H

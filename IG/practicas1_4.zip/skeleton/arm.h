#ifndef ARM_H
#define ARM_H

#include "elbow.h"
#include "forearm.h"

class _arm
{
public:
    _forearm Ante;
    _elbow Codo;
    int gradeElbow;
    int ratioCodo;

    void changeAnte();
    void moveElbow();
    void incrementarElbow();
    void decrementarElbow();
    void acelerarElbow();
    void decelerarElbow();

    void draw_point();
    void draw_line();
    void draw_fill();
    void draw_chess();
};

#endif // ARM_H

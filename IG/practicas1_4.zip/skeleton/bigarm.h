#ifndef BIGARM_H
#define BIGARM_H

#include "arm.h"
#include "cilindro.h"

class _bigarm
{
public:
    _arm Brazo;
    _cilindro Cilindro;

    void changeArm();
    void changeCilindro();

    void draw_point();
    void draw_line();
    void draw_fill();
    void draw_chess();
};

#endif // BIGARM_H

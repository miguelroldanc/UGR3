#include "semiesfera.h"

_semiesfera::_semiesfera(float Size, unsigned int n_caras, unsigned int vertices_perfil)
{
    const float HALF_PI = 3.1415/2.0;
    const float ROT = HALF_PI/vertices_perfil;
    float angulo_rot;
    float tam = Size/2;

    Vertices.resize(vertices_perfil+2);

    for (unsigned long i=1;i < vertices_perfil+1;++i){
        angulo_rot = i*ROT - (HALF_PI);
        Vertices[i-1] = _vertex3f(tam*cos(angulo_rot), tam*sin(angulo_rot), 0);
    }

    Vertices[Vertices.size()-2] = _vertex3f(0, 0, 0);
    Vertices[Vertices.size()-1] = _vertex3f(0, -tam, 0);

    revolucionarObjeto(Vertices, Triangles, n_caras, false);

    this->calcular_normales();
    this->calcular_normales_vertices();
}

void _semiesfera::calcular_normales_vertices(){

    unsigned long total_vertices;
    const _vertex3f B = {0,0,0};
    _vertex3f A;
    total_vertices = Vertices.size();
    Normales_Vertex.resize(total_vertices);

    for(unsigned long i=0;i < total_vertices;++i){
        A = Vertices[i];
        A._0 = A._0 - B._0;
        A._1 = A._1 - B._1;
        A._2 = A._2 - B._1;
        A = A.normalize();
        Normales_Vertex[i] = A;
    }

}

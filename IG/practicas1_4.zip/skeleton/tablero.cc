#include "tablero.h"

void _tablero::transformar(){
    glPushMatrix();
        glTranslatef(0,0,-0.0051);
        glScalef(1,1,0);
        Cubo.draw_fill();
    glPopMatrix();
}
void _tablero::draw_fill(){
    this->transformar();

    Cubo.parametros_textura();

    glBegin(GL_QUADS);
    // Primera cara
        glTexCoord2f(0.0,1.0);
        glVertex3f(-0.5,0.5,0.0);
        glTexCoord2f(1.0,1.0);
        glVertex3f(0.5,0.5,0.0);
        glTexCoord2f(1.0,0.0);
        glVertex3f(0.5,-0.5,0.0);
        glTexCoord2f(0.0,0.0);
        glVertex3f(-0.5,-0.5,0.0);
    glEnd();
    glDisable(GL_TEXTURE_2D);
}

#include "revolutionply.h"

_revolutionply::_revolutionply(unsigned long n_caras, bool sentido)
{
    _file_ply File_ply;
    if(File_ply.open("/home/miguel/Documents/3o/IG/perfil.ply")){
        File_ply.read(Vertices, Triangles);
        std::cout << "File read correctly" << std::endl;
    }else{
        std::cout << "File cannot be opened" << std::endl;
        abort();
    }

    revolucionarObjeto(Vertices, Triangles, n_caras, sentido);
    this->calcular_normales();
}

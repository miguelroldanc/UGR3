#ifndef TEXTURA_H
#define TEXTURA_H

#include "glwidget.h"
#include "vertex.h"
#include <vector>

class textura
{
public:
    _vertex4f ambient, diffuse, specular;
    float shininess;

    textura(const _vertex4f &amb, const _vertex4f &diff, const _vertex4f spec, float shiny);
    void usarTextura();
};

#endif // TEXTURA_H

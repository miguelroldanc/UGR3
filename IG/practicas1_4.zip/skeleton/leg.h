#ifndef LEG_H
#define LEG_H

#include "cilindro.h"
#include "semiesfera.h"

class _leg
{
public:
    _cilindro Cilindro;
    _semiesfera Semi;

    void changeCyl();
    void changeSemi();

    void draw_point();
    void draw_line();
    void draw_fill();
    void draw_chess();
};

#endif // LEG_H

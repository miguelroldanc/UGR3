#include "antena.h"

void _antena::changeCilindro(){
    glScalef(1,2,1);
}
void _antena::changeSemi(){
    glTranslatef(0,1,0);
    glRotatef(180,1,0,0);
}

void _antena::draw_point(){
    glPushMatrix();
    changeCilindro();
    Cilindro.draw_point();
    glPopMatrix();

    glPushMatrix();
    changeSemi();
    Semi.draw_point();
    glPopMatrix();
}
void _antena::draw_line(){
    glPushMatrix();
    changeCilindro();
    Cilindro.draw_line();
    glPopMatrix();

    glPushMatrix();
    changeSemi();
    Semi.draw_line();
    glPopMatrix();
}
void _antena::draw_fill(){
    glPushMatrix();
    changeCilindro();
    Cilindro.draw_fill();
    glPopMatrix();

    glPushMatrix();
    changeSemi();
    Semi.draw_fill();
    glPopMatrix();
}
void _antena::draw_chess(){
    glPushMatrix();
    changeCilindro();
    Cilindro.draw_chess();
    glPopMatrix();

    glPushMatrix();
    changeSemi();
    Semi.draw_chess();
    glPopMatrix();
}

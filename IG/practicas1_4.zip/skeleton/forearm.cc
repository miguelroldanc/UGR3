#include "forearm.h"

void _forearm::changeBotSemi(){
    glTranslatef(0,-0.5,0);
}
void _forearm::draw_point(){
    Cilindro.draw_point();

    glPushMatrix();
    changeBotSemi();
    Semi.draw_point();
    glPopMatrix();
}
void _forearm::draw_line(){
    Cilindro.draw_line();

    glPushMatrix();
    changeBotSemi();
    Semi.draw_line();
    glPopMatrix();
}
void _forearm::draw_fill(){
    Cilindro.draw_fill();

    glPushMatrix();
    changeBotSemi();
    Semi.draw_fill();
    glPopMatrix();
}
void _forearm::draw_chess(){
    Cilindro.draw_chess();

    glPushMatrix();
    changeBotSemi();
    Semi.draw_chess();
    glPopMatrix();
}


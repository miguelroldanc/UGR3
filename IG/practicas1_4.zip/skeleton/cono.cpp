#include "cono.h"

_cono::_cono(float Size, unsigned int n_caras)
{
    Vertices.resize(3);
    Vertices[0] = _vertex3f(Size/2, -Size/2, 0);
    Vertices[1] = _vertex3f(0, Size/2, 0);
    Vertices[2] = _vertex3f(0, -Size/2, 0);

    revolucionarObjeto(Vertices, Triangles, n_caras, true);
    this->calcular_normales();
    this->calcular_normales_vertices();
}

#ifndef REVOLUTION_H
#define REVOLUTION_H

#include "object3d.h"

class revolution:public _object3D
{
public:
    void addVerticesRotados(vector<_vertex3f>& Vertices, unsigned long perfil, unsigned long n_caras);
    void generarTriangulosCentrales(vector<_vertex3ui>& Triangles, unsigned long n_caras, unsigned long perfil, unsigned long totalVertices, unsigned long &start);
    void generarTriangulosSuperiores(vector<_vertex3ui>& Triangles, unsigned long n_caras, unsigned long perfil, unsigned long totalVertices, unsigned long &start, unsigned long n_tapas);
    void generarTriangulosInferiores(vector<_vertex3ui> &Triangles, unsigned long n_caras, unsigned long perfil, unsigned long totalVertices, unsigned long &start, unsigned long n_tapas);
    void revolucionarObjeto(vector<_vertex3f>& Vertices, vector<_vertex3ui>& Triangles, unsigned long n_caras, bool sentido);
};

#endif // REVOLUTION_H

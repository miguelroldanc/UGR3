#include <file_ply_stl.h>
#include <objeto_ply.h>
#include <iostream>
/*
int main()
{
  _objeto_ply File_ply;
  if (File_ply.open("/home/miguel/Documents/3o/IG/skeleton/chair3d.ply")){
    File_ply.read(Vertices,Triangles);
    std::cout << "File read correctly" << std::endl;
  }
  else std::cout << "File can't be opened" << std::endl;


}
*/

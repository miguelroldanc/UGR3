#ifndef PLAYER_H
#define PLAYER_H

#include "environment.h"

class Player{
    public:
      Player(int jug);
      Environment::ActionType Think();
      void Perceive(const Environment &env);
      double Poda_AlfaBeta(const Environment &actual_, int jugador, int profundidad, const int PROFUNDIDAD_ALFABETA, Environment::ActionType &accion, double alpha, double beta, bool esMax);
    private:
      int jugador_;
      Environment actual_;
};
#endif

#ifndef COMPORTAMIENTOJUGADOR_H
#define COMPORTAMIENTOJUGADOR_H

#include "comportamientos/comportamiento.hpp"

#include <list>

struct estado {
  int fila;
  int columna;
  int orientacion;
  bool operator==(const estado &est){
      bool stiguales=false;
      if(this->columna==est.columna){
        if(this->fila==est.fila){
            if(this->orientacion==est.orientacion){
                stiguales=true;
            }
        }
      }
      return stiguales;
  }
};

class ComportamientoJugador : public Comportamiento {
  public:
    ComportamientoJugador(unsigned int size) : Comportamiento(size) {
      // Inicializar Variables de Estado
      fil = col = 99;
      brujula = 0; // 0: Norte, 1:Este, 2:Sur, 3:Oeste
      destino.fila = -1;
      destino.columna = -1;
      destino.orientacion = -1;
      ultimaAccion = actIDLE;
      estoy_bien_situado= false;
      hayPlan = false;
      punto_encontrado=false;
      vector< unsigned char> aux(7,'?');
      for(unsigned int i = 0; i < 7; i++){
        mapaAux.push_back(aux);
      }
    }
    ComportamientoJugador(std::vector< std::vector< unsigned char> > mapaR) : Comportamiento(mapaR) {
      // Inicializar Variables de Estado
      fil = col = 99;
      brujula = 0; // 0: Norte, 1:Este, 2:Sur, 3:Oeste
      destino.fila = -1;
      destino.columna = -1;
      destino.orientacion = -1;
      ultimaAccion = actIDLE;
      estoy_bien_situado= false;
      hayPlan = false;
      punto_encontrado=false;
      vector< unsigned char> aux(8,'?');
      for(unsigned int i = 0; i < 8; i++){
        mapaAux.push_back(aux);
      }
    }

    ComportamientoJugador(const ComportamientoJugador & comport) : Comportamiento(comport){}
    ~ComportamientoJugador(){}

    Action think(Sensores sensores);
    int interact(Action accion, int valor);
    void VisualizaPlan(const estado &st, const list<Action> &plan);
    ComportamientoJugador * clone(){return new ComportamientoJugador(*this);}

  private:
    // Declarar Variables de Estado
    int fil, col, brujula;
    estado actual, destino;
    list<Action> plan;

    //Nuevas variables de estado
    Action ultimaAccion;
    bool hayPlan;
    bool estoy_bien_situado;
    bool punto_encontrado;
    vector<vector<unsigned char>> mapaAux;

    // M�todos privados de la clase
    bool pathFinding (int level, const estado &origen, const estado &destino, list<Action> &plan, const vector<vector<unsigned char>> &mapita);
    bool pathFinding_Profundidad(const estado &origen, const estado &destino, list<Action> &plan);
    bool pathFinding_Anchura(const estado &origen, const estado &destino, list<Action> &plan);
    bool pathFinding_CosteUniforme(const estado &origen, const estado &destino, list<Action> &plan, const vector<vector<unsigned char>> &mapa);
    bool pathFinding_Astar(const estado &origen, const estado &destino, list<Action> &plan, const vector<vector<unsigned char>> &mapa);
    void PintaPlan(list<Action> plan);
    bool HayObstaculoDelante(estado &st);

};

#endif

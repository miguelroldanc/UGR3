#include "../Comportamientos_Jugador/jugador.hpp"
#include "motorlib/util.h"

#include <iostream>
#include <cmath>
#include <set>
#include <stack>
#include <queue>
#include <vector>
bool EsObstaculo(unsigned char casilla);//Es necesario declararlo antes porque es usado en la funcion think

void pintar(const Sensores &missensores, vector<vector<unsigned char>> &mimapa, const estado &mist){
    mimapa[mist.fila][mist.columna]=missensores.terreno[0];
        int contador_sensor=1;
        switch(mist.orientacion){
            case 0:{
                //El agente mira hacia el norte
                for(int i=1;i<4;++i){
                    for(int j=-i;j<=i;++j,++contador_sensor){
                        mimapa[mist.fila-i][mist.columna+j]=missensores.terreno[contador_sensor];
                    }
                }
                break;
            }
            case 1:{
                //El agente mira hacia el este
                for(int j=1;j<4;++j){
                    for(int i=-j;i<=j;++i,++contador_sensor){
                        mimapa[mist.fila+i][mist.columna+j]=missensores.terreno[contador_sensor];
                    }
                }//si hay un aldeano delante, el agente espera a que se aparte
                break;
            }
            case 2:{
                //El agente mira hacia el sur
                for(int i=1;i<4;++i){
                    for(int j=i;j>=(-i);--j,++contador_sensor){
                        mimapa[mist.fila+i][mist.columna+j]=missensores.terreno[contador_sensor];
                    }
                }
                break;
            }
            case 3:{
                //El agente mira hacia el oeste
                for(int j=1;j<4;++j){
                    for(int i=j;i>=-j;--i,++contador_sensor){
                        mimapa[mist.fila+i][mist.columna-j]=missensores.terreno[contador_sensor];
                    }
                }
                break;
            }
        }
}

void encuentra_casilla(const vector<vector<unsigned char>> &mapita, estado &mistate){
    for(int i=0;i<7;++i){
        for(int j=0;j<7;++j){
            if(mapita[i][j]=='K'){
                mistate.fila=i;
                mistate.columna=j;
            }
        }
    }
}

// Este es el m�todo principal que debe contener los 4 Comportamientos_Jugador
// que se piden en la pr�ctica. Tiene como entrada la informaci�n de los
// sensores y devuelve la acci�n a realizar.
Action ComportamientoJugador::think(Sensores sensores){
    //Capturar los valores de filas y columnas
    //Solo recibe un mensaje distinto de -1 cuando se situa en una casilla PK
    if(sensores.mensajeF != -1 && !(estoy_bien_situado)){
        fil = sensores.mensajeF;
        col = sensores.mensajeC;
        ultimaAccion=actIDLE;
        estoy_bien_situado=true;
        hayPlan=false;
    }

    //Actualizar el efecto de la ultima accion
    switch(ultimaAccion){
        case actTURN_R: brujula = (brujula+1)%4;break;
        case actTURN_L: brujula = (brujula+3)%4;break;
        case actFORWARD:
            switch(brujula){
                case 0: fil--;break;
                case 1: col++;break;
                case 2:fil++;break;
                case 3:col--;break;
            }
            break;
    }

    //Dibujar mapa una vez el agente sabe su ubicacion real en el espacio
    if(estoy_bien_situado){
        estado auxst;
        auxst.columna=col;auxst.fila=fil;auxst.orientacion=brujula;
        pintar(sensores, mapaResultado, auxst);
    }else{
        //Se intenta localizar un punto amarillo para ubicarse en el espacio
        int punto=-1;
        for(int a=1;a<16 && !punto_encontrado;++a){
            if(sensores.terreno[a]=='K'){
                    punto_encontrado=true;
                    punto=a;
            }
        }

        if(punto_encontrado){
            estado origen_prov, dest_prov;
            origen_prov.fila=3;origen_prov.columna=3;origen_prov.orientacion=brujula;
            dest_prov.orientacion=brujula;
            pintar(sensores, mapaAux, origen_prov);
            encuentra_casilla(mapaAux, dest_prov);
            hayPlan=pathFinding(2, origen_prov, dest_prov, plan, mapaAux);
            punto_encontrado=false;
        }

    }

    //Mirar si ha cambiado el destino
    if(sensores.destinoF != destino.fila or sensores.destinoC != destino.columna){
        destino.fila = sensores.destinoF;
        destino.columna = sensores.destinoC;
        hayPlan = false;
    }

    //Calcular un camino a los objetivos
    if(!hayPlan && estoy_bien_situado){
        actual.fila = fil;
        actual.columna = col;
        actual.orientacion = brujula;
        hayPlan = pathFinding(sensores.nivel, actual, destino, plan, mapaResultado);
    }


    //si lo que hay delante es un muro o un precipicio no me vale el plan
    if(EsObstaculo(sensores.terreno[2])&&(plan.front()!=actTURN_L && plan.front()!=actTURN_R)&&(sensores.terreno[2]=='a')){
        hayPlan=false;
    }


    Action sigAccion;
    if(hayPlan and plan.size()>0){//Hay un plan y hay que seguirlo
        sigAccion = plan.front();
        plan.erase(plan.begin());
    }else{ //No hay plan y se activa un comportamiento reactivo
        static bool girito=false;
        static bool reciengire=false;

        if(sensores.terreno[2]=='a'){
            sigAccion=actIDLE;
        }else if(sensores.terreno[2]=='M' or sensores.terreno[2]=='P'){
            if(girito){
                sigAccion=actTURN_R;
            }else{
                sigAccion=actTURN_L;
            }
            reciengire=true;
        }else if(ultimaAccion==actTURN_L or ultimaAccion==actTURN_R){
            sigAccion=actFORWARD;
        }else if(reciengire){
            if(girito){
                sigAccion=actTURN_R;
                girito=false;
            }else{
                sigAccion=actTURN_L;
                girito=true;
            }
            reciengire=false;
        }else{
            sigAccion=actFORWARD;
        }
    }

    //Recordar la ultima accion
    ultimaAccion = sigAccion;
    return sigAccion;
}

// Llama al algoritmo de busqueda que se usar� en cada comportamiento del agente
// Level representa el comportamiento en el que fue iniciado el agente.
bool ComportamientoJugador::pathFinding (int level, const estado &origen, const estado &destino, list<Action> &plan, const vector<vector<unsigned char>> &mapita){
	switch (level){
		case 1: cout << "Busqueda en profundad\n";
			      return pathFinding_Profundidad(origen,destino,plan);
						break;
		case 2: cout << "Busqueda en Anchura\n";
			      return pathFinding_Anchura(origen,destino,plan);
						break;
		case 3: cout << "Busqueda Costo Uniforme\n";
                  return pathFinding_CosteUniforme(origen,destino,plan, mapita);
						break;
		case 4: cout << "Busqueda para el reto\n";
                  return pathFinding_Astar(origen,destino,plan, mapita);
						break;
	}
	cout << "Comportamiento sin implementar\n";
	return false;
}


//---------------------- Implementaci�n de la busqueda en profundidad ---------------------------

// Dado el c�digo en car�cter de una casilla del mapa dice si se puede
// pasar por ella sin riegos de morir o chocar.
bool EsObstaculo(unsigned char casilla){
	if (casilla=='P' or casilla=='M' or casilla =='D')
		return true;
	else
	  return false;
}


// Comprueba si la casilla que hay delante es un obstaculo. Si es un
// obstaculo devuelve true. Si no es un obstaculo, devuelve false y
// modifica st con la posici�n de la casilla del avance.
bool ComportamientoJugador::HayObstaculoDelante(estado &st){
	int fil=st.fila, col=st.columna;

  // calculo cual es la casilla de delante del agente
	switch (st.orientacion) {
		case 0: fil--; break;
		case 1: col++; break;
		case 2: fil++; break;
		case 3: col--; break;
	}

	// Compruebo que no me salgo fuera del rango del mapa
	if (fil<0 or fil>=mapaResultado.size()) return true;
	if (col<0 or col>=mapaResultado[0].size()) return true;

	// Miro si en esa casilla hay un obstaculo infranqueable
	if (!EsObstaculo(mapaResultado[fil][col])){
		// No hay obstaculo, actualizo el par�metro st poniendo la casilla de delante.
        st.fila = fil;
		st.columna = col;
		return false;
	}
	else{
	  return true;
	}
}




struct nodo{
	estado st;
	list<Action> secuencia;
	int coste;
	bool operator==(const nodo &nodd){
	    return this->st==nodd.st;
	}
};

//Implementaci�n del coste heuristico: distancia Manhattan
int costeHeuristico(const estado &origen, const estado &destino){
    int x_axis, y_axis, resultado;
    x_axis=abs((origen.fila)-(destino.fila));
    y_axis=abs((origen.columna)-(destino.columna));
    resultado=x_axis+y_axis;
    return 0.05*resultado;
}

//Calcula el coste de pasar por la casilla encasillado
int costeCasilla(unsigned char encasillado){
    switch(encasillado){
                case 'S'://Suelo pedregoso coste->1
                    return 1;
                case 'K'://Casilla amarilla coste->1
                    return 1;
                case 'T'://Suelo arenoso coste->2
                    return 2;
                case '?'://Casilla desconocida coste->4
                    return 4;
                case 'B'://Bosque coste->5
                    return 5;
                case 'A'://Agua coste->10
                    return 10;
				}
}

struct ComparaNodos{
	bool operator()(const nodo &a, const nodo &b) const{
	    return a.coste>b.coste;
	}
};

struct ComparaEstados{
	bool operator()(const estado &a, const estado &n) const{
		if ((a.fila > n.fila) or (a.fila == n.fila and a.columna > n.columna) or
	      (a.fila == n.fila and a.columna == n.columna and a.orientacion > n.orientacion))
			return true;
		else
			return false;
	}
};


//Comprobacion antes de insertar un nodo en la frontera
//Si el nodo a introducir ya esta en la frontera y tiene un coste superior se sustituye por el nuevo valor
void sustituirNodo(priority_queue<nodo, vector<nodo>,ComparaNodos> &que, const nodo &nuevo){
    stack<nodo> aux;
    bool encontrado=false;

    while(!que.empty()&&!encontrado){
        aux.push(que.top());
        que.pop();
        if(aux.top()==nuevo){
            encontrado=true;
            if(aux.top().coste>nuevo.coste){
                aux.pop();
                aux.push(nuevo);
            }
        }
    }
    if(!encontrado){
        aux.push(nuevo);
    }
    while(!aux.empty()){
        que.push(aux.top());
        aux.pop();
    }
}

// Implementaci�n de la b�squeda en profundidad.
// Entran los puntos origen y destino y devuelve la
// secuencia de acciones en plan, una lista de acciones.
bool ComportamientoJugador::pathFinding_Profundidad(const estado &origen, const estado &destino, list<Action> &plan) {
	//Borro la lista
	cout << "Calculando plan\n";
	plan.clear();
	set<estado,ComparaEstados> generados;                       // Lista de Cerrados
	stack<nodo> pila;											// Lista de Abiertos

  nodo current;
	current.st = origen;
	current.secuencia.empty();

	pila.push(current);

  while (!pila.empty() and (current.st.fila!=destino.fila or current.st.columna != destino.columna)){

		pila.pop();
		generados.insert(current.st);

		// Generar descendiente de girar a la derecha
		nodo hijoTurnR = current;
		hijoTurnR.st.orientacion = (hijoTurnR.st.orientacion+1)%4;
		if (generados.find(hijoTurnR.st) == generados.end()){
			hijoTurnR.secuencia.push_back(actTURN_R);
			pila.push(hijoTurnR);

		}

		// Generar descendiente de girar a la izquierda
		nodo hijoTurnL = current;
		hijoTurnL.st.orientacion = (hijoTurnL.st.orientacion+3)%4;
		if (generados.find(hijoTurnL.st) == generados.end()){
			hijoTurnL.secuencia.push_back(actTURN_L);
			pila.push(hijoTurnL);
		}

		// Generar descendiente de avanzar
		nodo hijoForward = current;
		if (!HayObstaculoDelante(hijoForward.st)){
			if (generados.find(hijoForward.st) == generados.end()){
				hijoForward.secuencia.push_back(actFORWARD);
				pila.push(hijoForward);
			}
		}

		// Tomo el siguiente valor de la pila
		if (!pila.empty()){
			current = pila.top();
		}
	}

  cout << "Terminada la busqueda\n";

	if (current.st.fila == destino.fila and current.st.columna == destino.columna){
		cout << "Cargando el plan\n";
		plan = current.secuencia;
		cout << "Longitud del plan: " << plan.size() << endl;
		PintaPlan(plan);
		// ver el plan en el mapa
		VisualizaPlan(origen, plan);
		return true;
	}
	else {
		cout << "No encontrado plan\n";
	}


	return false;
}

//Implementacion ce la busqueda en anchura
//Entran los puntos origen y destino y devuelve la
//secuencia de acciones en plan, una lista de acciones.
bool ComportamientoJugador::pathFinding_Anchura(const estado &origen, const estado &destino, list<Action> &plan) {
	//Borro la lista
	cout << "Calculando plan\n";
	plan.clear();
	set<estado,ComparaEstados> generados;                       // Lista de Cerrados
	queue<nodo> cola;											// Lista de Abiertos

  nodo current;
	current.st = origen;
	current.secuencia.empty();

	cola.push(current);

  while (!cola.empty() and (current.st.fila!=destino.fila or current.st.columna != destino.columna)){

		cola.pop();
		generados.insert(current.st);

		// Generar descendiente de girar a la derecha
		nodo hijoTurnR = current;
		hijoTurnR.st.orientacion = (hijoTurnR.st.orientacion+1)%4;
		if (generados.find(hijoTurnR.st) == generados.end()){
			hijoTurnR.secuencia.push_back(actTURN_R);
			cola.push(hijoTurnR);
		}

		// Generar descendiente de girar a la izquierda
		nodo hijoTurnL = current;
		hijoTurnL.st.orientacion = (hijoTurnL.st.orientacion+3)%4;
		if (generados.find(hijoTurnL.st) == generados.end()){
			hijoTurnL.secuencia.push_back(actTURN_L);
			cola.push(hijoTurnL);
		}

		// Generar descendiente de avanzar
		nodo hijoForward = current;
		if (!HayObstaculoDelante(hijoForward.st)){
			if (generados.find(hijoForward.st) == generados.end()){
				hijoForward.secuencia.push_back(actFORWARD);
				cola.push(hijoForward);
			}
		}

		// Tomo el siguiente valor de la cola
		if (!cola.empty()){
			current = cola.front();
		}
	}

  cout << "Terminada la busqueda\n";

	if (current.st.fila == destino.fila and current.st.columna == destino.columna){
		cout << "Cargando el plan\n";
		plan = current.secuencia;
		cout << "Longitud del plan: " << plan.size() << endl;
		PintaPlan(plan);
		// ver el plan en el mapa
		VisualizaPlan(origen, plan);
		return true;
	}
	else {
		cout << "No encontrado plan\n";
	}


	return false;
}

//Implementacion de la busqueda por coste uniforme
//Entran los puntos origen y destino y deuvuelve la
//secuencia de acciones en plan, una lista de acciones

bool ComportamientoJugador::pathFinding_CosteUniforme(const estado &origen, const estado &destino, list<Action> &plan, const vector<vector<unsigned char>> &mapa) {
	//Borro la lista
	cout << "Calculando plan\n";
	plan.clear();
	set<estado,ComparaEstados> generados;                                        // Lista de Cerrados
	priority_queue<nodo, vector<nodo>,ComparaNodos> cola_prio;                   // Lista de Abiertos
	char forwardbox;//Identificar el tipo de suelo que hay delante

  nodo current;
	current.st = origen;
	current.secuencia.empty();
	current.coste=0;

	cola_prio.push(current);

  while (!cola_prio.empty() and (current.st.fila!=destino.fila or current.st.columna != destino.columna)){

		cola_prio.pop();
		generados.insert(current.st);

		// Generar descendiente de girar a la derecha
		nodo hijoTurnR = current;
		hijoTurnR.st.orientacion = (hijoTurnR.st.orientacion+1)%4;
		if (generados.find(hijoTurnR.st) == generados.end()){
			hijoTurnR.secuencia.push_back(actTURN_R);
			hijoTurnR.coste+=1;
			cola_prio.push(hijoTurnR);

		}

		// Generar descendiente de girar a la izquierda
		nodo hijoTurnL = current;
		hijoTurnL.st.orientacion = (hijoTurnL.st.orientacion+3)%4;
		if (generados.find(hijoTurnL.st) == generados.end()){
			hijoTurnL.secuencia.push_back(actTURN_L);
			hijoTurnL.coste+=1;
			cola_prio.push(hijoTurnL);
		}

		// Generar descendiente de avanzar
		nodo hijoForward = current;
		if (!HayObstaculoDelante(hijoForward.st)){
			if (generados.find(hijoForward.st) == generados.end()){
				hijoForward.secuencia.push_back(actFORWARD);
                forwardbox=mapa[hijoForward.st.fila][hijoForward.st.columna];
                hijoForward.coste+=costeCasilla(forwardbox);
				sustituirNodo(cola_prio, hijoForward);
			}
		}

		// Tomo el siguiente valor de la pila
		if (!cola_prio.empty()){
			current = cola_prio.top();
		}
	}

  cout << "Terminada la busqueda\n";

	if (current.st.fila == destino.fila and current.st.columna == destino.columna){
		cout << "Cargando el plan\n";
		plan = current.secuencia;
		cout << "Longitud del plan: " << plan.size() << endl;
		PintaPlan(plan);
		// ver el plan en el mapa
		VisualizaPlan(origen, plan);
		return true;
	}
	else {
		cout << "No encontrado plan\n";
	}


	return false;
}

//Implementacion de la busqueda por A*
//Entran los puntos origen y destino y devuelve la
//secuencia de acciones en plan, una lista de acciones

bool ComportamientoJugador::pathFinding_Astar(const estado &origen, const estado &destino, list<Action> &plan, const vector<vector<unsigned char>> &mapa){
	//Borro la lista
	cout << "Calculando plan\n";
	plan.clear();
	set<estado,ComparaEstados> generados;                                        // Lista de Cerrados
	priority_queue<nodo, vector<nodo>,ComparaNodos> cola_prio;                   // Lista de Abiertos
	char forwardbox;//Identificar el tipo de suelo que hay delante

  nodo current;
	current.st = origen;
	current.secuencia.empty();
	current.coste=costeHeuristico(origen,destino);

	cola_prio.push(current);

  while (!cola_prio.empty() and (current.st.fila!=destino.fila or current.st.columna != destino.columna)){

		cola_prio.pop();
		generados.insert(current.st);

		// Generar descendiente de girar a la derecha
		nodo hijoTurnR = current;
		hijoTurnR.st.orientacion = (hijoTurnR.st.orientacion+1)%4;
		if (generados.find(hijoTurnR.st) == generados.end()){
			hijoTurnR.secuencia.push_back(actTURN_R);
			hijoTurnR.coste=hijoTurnR.coste+1+costeHeuristico(hijoTurnR.st,destino);
			cola_prio.push(hijoTurnR);

		}

		// Generar descendiente de girar a la izquierda
		nodo hijoTurnL = current;
		hijoTurnL.st.orientacion = (hijoTurnL.st.orientacion+3)%4;
		if (generados.find(hijoTurnL.st) == generados.end()){
			hijoTurnL.secuencia.push_back(actTURN_L);
			hijoTurnL.coste=hijoTurnL.coste+1+costeHeuristico(hijoTurnL.st,destino);
			cola_prio.push(hijoTurnL);
		}

		// Generar descendiente de avanzar
		nodo hijoForward = current;
		if (!HayObstaculoDelante(hijoForward.st)){
			if (generados.find(hijoForward.st) == generados.end()){
				hijoForward.secuencia.push_back(actFORWARD);
                forwardbox=mapa[hijoForward.st.fila][hijoForward.st.columna];
                hijoForward.coste=hijoForward.coste+costeCasilla(forwardbox)+costeHeuristico(hijoForward.st,destino);
				sustituirNodo(cola_prio, hijoForward);
			}
		}

		// Tomo el siguiente valor de la pila
		if (!cola_prio.empty()){
			current = cola_prio.top();
		}
	}

  cout << "Terminada la busqueda\n";

	if (current.st.fila == destino.fila and current.st.columna == destino.columna){
		cout << "Cargando el plan\n";
		plan = current.secuencia;
		cout << "Longitud del plan: " << plan.size() << endl;
		PintaPlan(plan);
		// ver el plan en el mapa
		VisualizaPlan(origen, plan);
		return true;
	}
	else {
		cout << "No encontrado plan\n";
	}


	return false;
}


// Sacar por la t�rminal la secuencia del plan obtenido
void ComportamientoJugador::PintaPlan(list<Action> plan) {
	auto it = plan.begin();
	while (it!=plan.end()){
		if (*it == actFORWARD){
			cout << "A ";
		}
		else if (*it == actTURN_R){
			cout << "D ";
		}
		else if (*it == actTURN_L){
			cout << "I ";
		}
		else {
			cout << "- ";
		}
		it++;
	}
	cout << endl;
}



void AnularMatriz(vector<vector<unsigned char> > &m){
	for (int i=0; i<m[0].size(); i++){
		for (int j=0; j<m.size(); j++){
			m[i][j]=0;
		}
	}
}


// Pinta sobre el mapa del juego el plan obtenido
void ComportamientoJugador::VisualizaPlan(const estado &st, const list<Action> &plan){
  AnularMatriz(mapaConPlan);
	estado cst = st;

	auto it = plan.begin();
	while (it!=plan.end()){
		if (*it == actFORWARD){
			switch (cst.orientacion) {
				case 0: cst.fila--; break;
				case 1: cst.columna++; break;
				case 2: cst.fila++; break;
				case 3: cst.columna--; break;
			}
			mapaConPlan[cst.fila][cst.columna]=1;
		}
		else if (*it == actTURN_R){
			cst.orientacion = (cst.orientacion+1)%4;
		}
		else {
			cst.orientacion = (cst.orientacion+3)%4;
		}
		it++;
	}
}



int ComportamientoJugador::interact(Action accion, int valor){
  return false;
}

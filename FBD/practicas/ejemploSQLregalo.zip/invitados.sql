--------------------------------------------------------
-- Archivo creado  - jueves-abril-04-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table INVITADOS
--------------------------------------------------------

  CREATE TABLE "X5577840"."INVITADOS" 
   (	"NOMBRE" VARCHAR2(20 BYTE), 
	"DIRECCION" VARCHAR2(20 BYTE), 
	"CIUDAD" VARCHAR2(10 BYTE) DEFAULT 'Granada', 
	"N_PERSONAS" NUMBER(1,0) DEFAULT '1'
   ) SEGMENT CREATION DEFERRED 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  TABLESPACE "BDCCIA" ;
REM INSERTING into X5577840.INVITADOS
SET DEFINE OFF;
--------------------------------------------------------
--  DDL for Index SYS_C00145628
--------------------------------------------------------

  CREATE UNIQUE INDEX "X5577840"."SYS_C00145628" ON "X5577840"."INVITADOS" ("NOMBRE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "BDCCIA" ;
--------------------------------------------------------
--  Constraints for Table INVITADOS
--------------------------------------------------------

  ALTER TABLE "X5577840"."INVITADOS" MODIFY ("DIRECCION" NOT NULL ENABLE);
  ALTER TABLE "X5577840"."INVITADOS" ADD CHECK (ciudad in ('Malaga','Granada','Jaen','Almeria')) ENABLE;
  ALTER TABLE "X5577840"."INVITADOS" ADD PRIMARY KEY ("NOMBRE")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "BDCCIA"  ENABLE;

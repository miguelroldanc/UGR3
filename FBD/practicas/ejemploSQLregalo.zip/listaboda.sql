--------------------------------------------------------
-- Archivo creado  - jueves-abril-04-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table LISTA_BODA
--------------------------------------------------------

  CREATE TABLE "X5577840"."LISTA_BODA" 
   (	"COD_REF" VARCHAR2(8 BYTE), 
	"DESCRIPCION" VARCHAR2(40 BYTE), 
	"PRECIO" NUMBER(4,2)
   ) SEGMENT CREATION DEFERRED 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  TABLESPACE "BDCCIA" ;
REM INSERTING into X5577840.LISTA_BODA
SET DEFINE OFF;
--------------------------------------------------------
--  DDL for Index SYS_C00145583
--------------------------------------------------------

  CREATE UNIQUE INDEX "X5577840"."SYS_C00145583" ON "X5577840"."LISTA_BODA" ("COD_REF") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "BDCCIA" ;
--------------------------------------------------------
--  Constraints for Table LISTA_BODA
--------------------------------------------------------

  ALTER TABLE "X5577840"."LISTA_BODA" MODIFY ("PRECIO" NOT NULL ENABLE);
  ALTER TABLE "X5577840"."LISTA_BODA" ADD PRIMARY KEY ("COD_REF")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "BDCCIA"  ENABLE;

--------------------------------------------------------
-- Archivo creado  - jueves-abril-04-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table REGALO_RESERVADO
--------------------------------------------------------

  CREATE TABLE "X5577840"."REGALO_RESERVADO" 
   (	"COD_REF" VARCHAR2(8 BYTE), 
	"NOMBRE" VARCHAR2(20 BYTE), 
	"FECHA" DATE
   ) SEGMENT CREATION DEFERRED 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  TABLESPACE "BDCCIA" ;
REM INSERTING into X5577840.REGALO_RESERVADO
SET DEFINE OFF;
--------------------------------------------------------
--  DDL for Index SYS_C00145722
--------------------------------------------------------

  CREATE UNIQUE INDEX "X5577840"."SYS_C00145722" ON "X5577840"."REGALO_RESERVADO" ("COD_REF", "NOMBRE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "BDCCIA" ;
--------------------------------------------------------
--  Constraints for Table REGALO_RESERVADO
--------------------------------------------------------

  ALTER TABLE "X5577840"."REGALO_RESERVADO" MODIFY ("COD_REF" NOT NULL ENABLE);
  ALTER TABLE "X5577840"."REGALO_RESERVADO" MODIFY ("NOMBRE" NOT NULL ENABLE);
  ALTER TABLE "X5577840"."REGALO_RESERVADO" MODIFY ("FECHA" NOT NULL ENABLE);
  ALTER TABLE "X5577840"."REGALO_RESERVADO" ADD CHECK (fecha between to_date ('22/05/2017', 'dd/mm/yyyy') and to_date('22/06/2017', 'dd/mm/yyyy')) ENABLE;
  ALTER TABLE "X5577840"."REGALO_RESERVADO" ADD PRIMARY KEY ("COD_REF", "NOMBRE")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "BDCCIA"  ENABLE;

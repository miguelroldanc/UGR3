//
// YodafyServidorIterativo
// (CC) jjramos, 2012
//
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.*;

public class ParkingClienteTCP {

	public static void main(String[] args) {

		// Nombre del host donde se ejecuta el servidor:
		String host="localhost";
		//Opcion a realizar
		String opcion = null;
		//Respuesta del servidor
		String respuesta = null;
		//Booleano para acabar el sistema
		boolean salir = false;
		// Puerto en el que espera el servidor:
		int port=8989;

		Scanner teclado = new Scanner(System.in);

		String tipo;
		String matricula = null;
		String HoraEntrada = null;
		String HoraSalida = null;
		// Socket para la conexión TCP
		Socket socketServicio=null;

		try {
			// Creamos un socket que se conecte a "host" y "port":
			//////////////////////////////////////////////////////
			socketServicio = new Socket(host, port);
			PrintWriter outPrinter = new PrintWriter(socketServicio.getOutputStream(), true);
			BufferedReader inReader = new BufferedReader(new InputStreamReader(socketServicio.getInputStream()));

			//Inicio de la interaccion entre el servidor y el cliente
			System.out.println("Bienvenid@.");
		
				System.out.println("¿Qué desea hacer?");
				System.out.println("Reservar  CancelarReserva  EntrarParking  SalirParking  VerPrecio  VerPlaza  PlazasDisponibles  Salir");
				opcion = teclado.nextLine();

				switch(opcion){

					case "Reservar":
						outPrinter.println("Reservar");

						System.out.println("Introduzca la matrícula del coche: ");
						matricula = teclado.nextLine();
						outPrinter.println(matricula);
						System.out.println("Introduzca cuantas horas quieres reservar: ");
						HoraSalida = teclado.nextLine();
						outPrinter.println(HoraSalida);

						respuesta = inReader.readLine();
						System.out.println(respuesta);
					break;

					case "CancelarReserva":
						outPrinter.println("CancelarReserva");

						System.out.println("Introduzca la matrícula del coche: ");
						matricula = teclado.nextLine();

						outPrinter.println(matricula);

						respuesta = inReader.readLine();
						System.out.println(respuesta);
					break;

					case "EntrarParking":
						outPrinter.println("EntrarParking");

						System.out.println("Introduzca la matrícula del coche: ");
						matricula = teclado.nextLine();
						outPrinter.println(matricula);
						System.out.println("¿Que hora es? ");
						HoraEntrada = teclado.nextLine();
						outPrinter.println(HoraEntrada);

						respuesta = inReader.readLine();
						System.out.println(respuesta);
					break;

					case "SalirParking":
						outPrinter.println("SalirParking");

						System.out.println("Introduzca la matrícula del coche: ");
						matricula = teclado.nextLine();
						outPrinter.println(matricula);
						System.out.println("¿Que hora es? ");
						HoraSalida = teclado.nextLine();
						outPrinter.println(HoraSalida);
						System.out.println("¿Has reservado? (s/n) ");
						tipo = teclado.nextLine();
						outPrinter.println(tipo);

						respuesta = inReader.readLine();
						System.out.println(respuesta);
					break;

					case "VerPrecio":
						outPrinter.println("VerPrecio");

						System.out.println("Introduzca la matrícula del coche: ");
						matricula = teclado.nextLine();
						outPrinter.println(matricula);
						System.out.println("¿Que hora es? ");
						HoraSalida = teclado.nextLine();
						outPrinter.println(HoraSalida);
						System.out.println("¿Has reservado? (s/n) ");
						tipo = teclado.nextLine();
						outPrinter.println(tipo);

						respuesta = inReader.readLine();
						System.out.println(respuesta);
					break;

					case "VerPlaza":
						outPrinter.println("VerPlaza");

						System.out.println("Introduzca la matrícula del coche: ");
						matricula = teclado.nextLine();
						System.out.println("¿Has reservado? (s/n) ");
						tipo = teclado.nextLine();

						outPrinter.println(matricula);
						outPrinter.println(tipo);

						respuesta = inReader.readLine();
						System.out.println(respuesta);
					break;

					case "PlazasDisponibles":

						outPrinter.println("PlazasDisponibles");

						System.out.println("¿Ver plazas reservadas? (s/n)");
						tipo = teclado.nextLine();

						outPrinter.println(tipo);

						respuesta = inReader.readLine();
						System.out.println(respuesta);
					break;

					case "Salir":
						outPrinter.println("Salir");
						salir = true;

					break;


					default:
						System.out.println("Opcion introducida no valida, pruebe otra vez.");
				}

			System.out.println("Gracias");
			socketServicio.close();
			//////////////////////////////////////////////////////

			// Excepciones:
		} catch (UnknownHostException e) {
			System.err.println("Error: Nombre de host no encontrado.");
		} catch (IOException e) {
			System.err.println("Error de entrada/salida al abrir el socket.");
		}
	}
}

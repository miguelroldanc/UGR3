import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

//
// YodafyServidorIterativo
// (CC) jjramos, 2012
//
public class ParkingServidorIterativo {

	public static void main(String[] args) {
	    //Creación de los sockets
        ServerSocket socketServidor;
        Socket socketConexion = null;

		// Puerto de escucha
		int port=8989;
		// String auxiliar para recibir o enviar datos
		String cadena;

		try {
			// Abrimos el socket en modo pasivo, escuchando el en puerto indicado por "port"
			//////////////////////////////////////////////////
			socketServidor = new ServerSocket(port);
			//////////////////////////////////////////////////
			// Creamos el procesador
			ProcesadorParking procesador=new ProcesadorParking();
			//////////////////////////////////////////////////
			// Mientras ... siempre!
			do {

				// Aceptamos una nueva conexión con accept()
				/////////////////////////////////////////////////
				try{
				    socketConexion = socketServidor.accept();
				    procesador.setSocket(socketConexion);
				}catch (IOException e){
				    System.out.println("Error: no se pudo aceptar la conexión solicitada");
				}

				//////////////////////////////////////////////////

				// Creamos un objeto de la clase ProcesadorYodafy, pasándole como
				// argumento el nuevo socket, para que realice el procesamiento
				// Este esquema permite que se puedan usar hebras más fácilmente.
				procesador.procesa();

			} while (true);

		} catch (IOException e) {
			System.out.println("Error: no se pudo atender en el puerto "+port);
		}

	}

}

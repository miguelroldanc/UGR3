import java.io.*;
import java.net.Socket;
import java.util.*;

public class plaza{
    // Declaracion de las variables de la clase
    public String matricula;
    public int hora_inicial;
    public int hora_final;
    public boolean estado;
    public final int MAX_MATRICULA = 5;

    plaza(){}

    public void inicializar(boolean ocupada){
        this.estado = ocupada;

        if(ocupada){
            this.matricula = getMatricula(MAX_MATRICULA);
            this.hora_inicial = (int)(new Random().nextFloat() * 24.00);
        }else{
            this.matricula = "-";
            this.hora_inicial = 0;
        }
    }

    // Obtiene una matricula aleatoria con cinco caracteres
    public String getMatricula(int n){
        // limite inferior A
        int limInferior = 65;

        // limite superior Z
        int limSuperior = 90;

        // Generador aleatorio
        Random random = new Random();

        // Creacion de un StringBuffer para almacenar el resultado
        StringBuffer res = new StringBuffer(n);

        // Creacion de la cadena
        for(int i=0;i<n;++i){
            // Escoge un valor entre limInferior y limSuperior
            int sigChar = limInferior + (int)(random.nextFloat() * (limSuperior - limInferior + 1));

            // Concatena el caracter al final de r
            res.append((char)sigChar);
        }

        // Devuelve la cadena resultado
        return res.toString();
    }
}

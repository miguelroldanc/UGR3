//
// ProcesadorParking
//
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Random;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.io.InputStreamReader;



//
// Nota: si esta clase extendiera la clase Thread, y el procesamiento lo hiciera el método "run()",
// ¡Podríamos realizar un procesado concurrente!
//
public class ProcesadorParking {
	// Referencia a un socket para enviar/recibir las peticiones/respuestas
	private Socket socketServicio;
	// stream de lectura (por aquí se recibe lo que envía el cliente)
	private InputStream inputStream;
	// stream de escritura (por aquí se envía los datos al cliente)
	private OutputStream outputStream;
	// Variables para la creacion de las plazas
	public final int NUM_PLAZAS = 50;
	public final int NUM_PLAZAS_RESERVA = 10;
	public final int PRECIO_HORA = 2;
	public final int PRECIO_HORA_RESERVA = 3;
	public plaza parking[];
	public plaza parking_reserva[];

	ProcesadorParking(){
		this.socketServicio = null;

		parking = new plaza[NUM_PLAZAS];
		parking_reserva = new plaza[NUM_PLAZAS_RESERVA];
		boolean ran;
		for(int i=0;i<NUM_PLAZAS;i++){
				ran = (new Random()).nextBoolean();
				parking[i] = new plaza();
				parking[i].inicializar(ran);
		}
		for(int j=0;j<NUM_PLAZAS_RESERVA;j++){
				ran = (new Random()).nextBoolean();
				parking_reserva[j] = new plaza();
				parking_reserva[j].inicializar(ran);
		}
	}

    // metodo set para referenciar un socket
    public void setSocket(Socket socketServicio){
        this.socketServicio=socketServicio;
    }


		// Calculo del precio del parking según horas
			// Parametros de entrada
		// String matricula: tiene la matricula del vehiculo a buscar
			// boolean tipoParking: es true si es una reserva y false si es parking normal
			// int hora_final: hora a la que sale el vehiculo del parking
			// Devuelve el precio conforme al tiempo y tipo de parking (-1 para casos de error)
		int verPrecio(String m, boolean tipoParking, int hora_final){
				//Primero se mira si esta el coche en el parking
				int pos = estaVehiculo(m, tipoParking);
				int precio_final = 0;

				if(pos < 0)
						return -1;

				//Calculo del precio
				if(tipoParking == true){
						if(hora_final < parking_reserva[pos].hora_inicial)
								precio_final = ( (hora_final+24) - parking_reserva[pos].hora_inicial) * PRECIO_HORA_RESERVA;
						else
								precio_final = (hora_final - parking_reserva[pos].hora_inicial) * PRECIO_HORA_RESERVA;
				}else{
						if(hora_final < parking[pos].hora_inicial)
								precio_final = ( (hora_final+24) - parking[pos].hora_inicial) * PRECIO_HORA;
						else
								precio_final = (hora_final - parking[pos].hora_inicial) * PRECIO_HORA;
				}

				//Devolver el precio
				return precio_final;
		}

		// Ver lugar donde se encuentra el vehiculo
		// Parametros de entrada
		// String matricula: tiene la matricula del vehiculo a buscar
		// boolean tipoParking: es true si es una reserva y false si es parking normal
		// Devuelve la posicion del coche (-1 si no se encuentra)
		int estaVehiculo(String m, boolean tipoParking){
				int pos = -1;
				if(tipoParking == true){
						for(int i=0;i<NUM_PLAZAS_RESERVA;i++){
								if(parking_reserva[i].matricula.equals(m))
										pos = i;
						}
				}else{
						for(int i=0;i<NUM_PLAZAS;i++){
								if(parking[i].matricula.equals(m))
										pos = i;
						}
				}
				return pos;
		}

		// Mostrar plazas disponibles
		// Parametros de entrada
		// boolean tipoParking: es true si es una reserva y false si es parking normal
		// Devuelve el numero de plazas libres en un tipo de parking
		int mostrarPlazas(boolean tipoParking){
				int num_plazas = 0;
				if(tipoParking == true){
						for(int i=0;i<NUM_PLAZAS_RESERVA;i++){
								if(parking_reserva[i].estado == true)
										num_plazas++;
						}
				}else{
						for(int i=0;i<NUM_PLAZAS;i++){
								if(parking[i].estado == true)
										num_plazas++;
						}
				}

				return num_plazas;
		}

		int reservar(String m, int horas){
			int i = 0;
			boolean encontrado = false;
			while(i < NUM_PLAZAS_RESERVA && encontrado == false){
				if(parking_reserva[i].estado == true){
					encontrado = true;
					parking_reserva[i].matricula = m;
					parking_reserva[i].hora_final = horas;
					parking_reserva[i].estado = false;
				}else{
					i++;
				}
			}
			return i;
		}

		int entrar(String m, int horas){
			int i = 0;
			boolean encontrado = false;
			while(i < NUM_PLAZAS && encontrado == false){
				if(parking_reserva[i].estado == true){
					encontrado = true;
					parking[i].matricula = m;
					parking[i].hora_inicial = horas;
					parking[i].estado = false;
				}else{
					i++;
				}
			}
			return i;
		}

		int salir(String m){
			int i = 0;
			boolean encontrado = false;
			while(i < NUM_PLAZAS && encontrado == false){
				if(parking[i].matricula.equals(m)){
					encontrado = true;
					parking[i].estado = true;
					parking[i].matricula = "-";
				}else{
					i++;
				}
			}
			return i;
		}

		boolean cancelar_reserva(String m){
			boolean encontrado = false;
			for(int i = 0; i < NUM_PLAZAS_RESERVA; i++){
				if(parking_reserva[i].matricula.equals(m)){
					encontrado = true;
					parking_reserva[i].estado = true;
					parking_reserva[i].matricula = "-";
				}
			}
			return encontrado;
		}

	// Aquí es donde se realiza el procesamiento realmente:
	void procesa(){
		try {
			int i;
			int precio;
			boolean encontrado;
			boolean salir = false;
			String respuesta = null;
			String matricula = null;
			String Hora = null;
			String opcion = null;
			int n_Hora;
			String tipo_reserva = null;
			boolean b_reserva;
			PrintWriter outPrinter = new PrintWriter(socketServicio.getOutputStream(), true);
			BufferedReader inReader = new BufferedReader(new InputStreamReader(socketServicio.getInputStream()));

			opcion = inReader.readLine();

				switch(opcion){

					case "Reservar":
						matricula = inReader.readLine();
						Hora = inReader.readLine();

						n_Hora = Integer.parseInt(Hora);

						i = reservar(matricula, n_Hora);

						if(i < NUM_PLAZAS_RESERVA){
							respuesta = "Reserva realizada en la plaza " + i;
						}else{
							respuesta = "No hay plaza disponible para reservar.";
						}

						outPrinter.println(respuesta);
					break;

					case "CancelarReserva":
						matricula = inReader.readLine();

						encontrado = cancelar_reserva(matricula);

						if(encontrado == true){
							respuesta = "Reserva cancelada con exito.";
						}else{
							respuesta = "No hay plaza reservada a dicho automovil.";
						}

						outPrinter.println(respuesta);
					break;

					case "EntrarParking":
						matricula = inReader.readLine();
						Hora = inReader.readLine();

						n_Hora = Integer.parseInt(Hora);

						i = entrar(matricula, n_Hora);

						if(i < NUM_PLAZAS){
							respuesta = "Su auto ocupa ahora la plaza " + i;
						}else{
							respuesta = "No hay plaza disponibles.";
						}

						outPrinter.println(respuesta);
					break;

					case "SalirParking":
						i = 0;
						matricula = inReader.readLine();
						Hora = inReader.readLine();
						tipo_reserva = inReader.readLine();

						if(tipo_reserva.equals("s")){
							b_reserva = true;
						}else{
							b_reserva = false;
						}
						n_Hora = Integer.parseInt(Hora);

						precio = verPrecio(matricula, b_reserva, n_Hora);
						if(precio == -1){
							respuesta = "Su automovil no se encuentra en niguna plaza.";
						}else{
							i = salir(matricula);
							respuesta = "Su automovil ocupa la plaza: " + i + " precio a pagar: " + precio;
						}

						outPrinter.println(respuesta);
					break;

					case "VerPrecio":
						matricula = inReader.readLine();
						Hora = inReader.readLine();
						tipo_reserva = inReader.readLine();

						n_Hora = Integer.parseInt(Hora);
						if(tipo_reserva.equals("s")){
							b_reserva = true;
						}else{
							b_reserva = false;
						}

						precio = verPrecio(matricula, b_reserva, n_Hora);

						if(precio == -1){
							respuesta = "Su automovil no se encuentra en niguna plaza.";
						}else{
							respuesta = "Precio a pagar: " + precio;
						}

						outPrinter.println(respuesta);
					break;

					case "VerPlaza":
						matricula = inReader.readLine();
						tipo_reserva = inReader.readLine();

						if(tipo_reserva.equals("s")){
							b_reserva = true;
						}else{
							b_reserva = false;
						}

						int pos = estaVehiculo(matricula, b_reserva);

						if(pos == -1){
							respuesta = "Su automovil no se encuentra en niguna plaza.";
						}else{
							respuesta = "Su vehiculo se encuentra en la plaza: " + pos;
						}

						outPrinter.println(respuestSu automóvil ocupa la plaza i a);
					break;

					case "PlazasDisponibles":
						tipo_reserva = inReader.readLine();

						if(tipo_reserva.equals("s")){
							b_reserva = true;
						}else{
							b_reserva = false;
						}

						int n_plazas = mostrarPlazas(b_reserva);

						if(n_plazas == 0){
							respuesta = "No quedan plazas.";
						}else{
							respuesta = "Hay : " + n_plazas + " plazas disponibles.";
						}

						outPrinter.println(respuesta);
					break;

					case "Salir":
						salir = true;
					break;

					default:
				}



		} catch (IOException e) {
			System.err.println("Error al obtener los flujso de entrada/salida.");
		}

	}
}

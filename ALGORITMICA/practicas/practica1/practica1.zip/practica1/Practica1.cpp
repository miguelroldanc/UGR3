// Ejemplo de la ordenacion por burbuja sobre un vector de enteros

#include <cstdlib> // Para usar srand y rand
#include <chrono>
#include <iostream>
#include <fstream> // Para usar ficheros
using namespace std;

void OrdenaBurbuja(int *v, int n);
void MergeSort(int *v, int ini, int fin);
void combina(int *v, int ini, int med, int fin);
void HeapSort(int *v, int n);
void insertar(double *apo, int &tamapo, double valor);

int main(int argc, char *argv[]) {
	
	int *v, *v1, *v2;
	int n, i, argumento;
    chrono::time_point<std::chrono::high_resolution_clock> ti0, ti1, ti2, tf0, tf1, tf2; // Para medir el tiempo de ejecución
	unsigned long int semilla;
	ofstream fsalida;
	
	if (argc <= 3) {
		cerr<<"\nError: El programa se debe ejecutar de la siguiente forma.\n\n";
		cerr<<argv[0]<<" NombreFicheroSalida Semilla tamCaso1 tamCaso2 ... tamCasoN\n\n";
		return 0;
	}
	
	// Abrimos fichero de salida
	fsalida.open(argv[1]);
	if (!fsalida.is_open()) {
		cerr<<"Error: No se pudo abrir fichero para escritura "<<argv[1]<<"\n\n";
		return 0;
	}
	
	// Inicializamos generador de no. aleatorios
	semilla= atoi(argv[2]);
	srand(semilla);
	
	for (argumento= 3; argumento<argc; argumento++) {
		
		// Cogemos el tamanio del caso
		n= atoi(argv[argumento]);
		
		// Reservamos memoria para el vector
		v= new int[n];
		v1=new int[n];
		v2=new int[n];
		// Generamos vector aleatorio de prueba, con componentes entre 0 y n-1
		for (i= 0; i<n; i++){
			v[i]= rand()%n;
			v1[i]=v[i];
			v2[i]=v[i];
		}
		cerr << "Ejecutando algoritmos para tam. caso: " << n << endl;
		
		ti0= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que comienza la ejecuciÛn del algoritmo
		MergeSort(v, 0, n-1); // Ejecutamos el algoritmo para tamaÒo de caso tam
		tf0= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que finaliza la ejecuciÛn del algoritmo

		ti1= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que comienza la ejecuciÛn del algoritmo
		HeapSort(v1, n); // Ejecutamos el algoritmo para tamaÒo de caso tam
		tf1= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que finaliza la ejecuciÛn del algoritmo
		
		ti2= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que comienza la ejecuciÛn del algoritmo
		OrdenaBurbuja(v2, n); // Ejecutamos el algoritmo para tamaÒo de caso tam
		tf2= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que finaliza la ejecuciÛn del algoritmo
		unsigned long tejecucion= std::chrono::duration_cast<std::chrono::microseconds>(tf0 - ti0).count();
		unsigned long tejecucion1= std::chrono::duration_cast<std::chrono::microseconds>(tf1 - ti1).count();
		unsigned long tejecucion2= std::chrono::duration_cast<std::chrono::microseconds>(tf2 - ti2).count();
		
		// Guardamos tam. de caso y t_ejecucion a fichero de salida
		fsalida<<n<<" "<<tejecucion<<"  "<<tejecucion1<<"  "<<tejecucion2<<"\n";
		
		
		// Liberamos memoria del vector
		delete []v;
		delete []v1;
		delete []v2;
	}


	// Cerramos fichero de salida
	fsalida.close();
	cerr<<"Datos disponibles en el fichero generado\n";
	return 0;
}


void OrdenaBurbuja(int *v, int n) {
	
	int i, j, aux;
	bool haycambios= true;
	
	i= 0;
	while (haycambios) {
		
	 haycambios=false; // Suponemos vector ya ordenado
	 for (j= n-1; j>i; j--) { // Recorremos vector de final a i
		 
		 if (v[j-1]>v[j]) { // Dos elementos consecutivos mal ordenados
		  aux= v[j]; // Los intercambiamos
		  v[j]= v[j-1];
		  v[j-1]= aux;
		  haycambios= true; // Al intercambiar, hay cambio
		 }
	 }
	}
}

void MergeSort(int *v, int ini, int fin){
	if(ini < fin){
		int med = (ini + fin)/2;
		MergeSort(v, ini, med);
		MergeSort(v, med+1, fin);
		combina(v, ini, med, fin);
	}
}

void combina(int *v, int ini, int med, int fin){
	int vtam = fin - ini + 1;
	int* aux = new int[vtam];
	int i=ini, j = med+1, k=0;

	while(i<=med && j<=fin){
		if(v[i]<v[j]){ aux[k]= v[i]; ++i;}
		else{ aux[k] = v[j]; ++j;}
		++k;
	}

	while(i<=med){aux[k] = v[i]; ++i; ++k;}
	while(j <=fin){aux[k] = v[j]; ++j; ++k;}

	for(int n=0;n<vtam;++n) v[ini+n] = aux[n];
	delete []aux;
}

void HeapSort(int *v, int n){
	double* apo=new double[n];
	int tamapo=0;

	for(int i=0;i<n;++i) insertar(apo,tamapo,v[i]);

	for(int i=0;i<n;++i){
//Como no conozco la función borrarRaiz diseño el algoritmo menos complejo
		v[i]=apo[n];
	}
	delete []apo;

}

void insertar(double *apo, int &tamapo, double valor){
	apo[tamapo]=valor;
	++tamapo;
	int aux=tamapo-1;
	bool fin=false;
	while(!fin){
		int padre;
		if(aux==0)fin=true;
		else{
			if(aux%2==0)padre=(aux-2)/2;
			else padre=(aux-1)/2;

			if(apo[padre] > apo[aux]){
				double tmp=apo[aux];
				apo[aux]=apo[padre];
				apo[padre]=tmp;
				aux=padre;
			}else fin=true;

		}

	}
}


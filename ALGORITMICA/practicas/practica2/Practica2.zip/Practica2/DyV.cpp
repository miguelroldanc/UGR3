#include <iostream>
#include <ctime>
using namespace std;

//--------------------------------------------------Funciones--------------------------------------------------
//Caso base: es el encargado de pintar en la matriz
//El nodo raiz tiene 0, 1 o 2 hijos

void CasoBase(const int lil[], int size, bool** res){
	for(int i=1;i<size;++i){
		res[lil[0]][lil[i]]=true;
	}
}
//--------------------------------------------------
//Funcion DyV: subdivide el caso en casos mas pequeños equivalentes
//Devuelve la matriz de adyacencia

void DyV(const int abbcompleto[], int size, bool** res){
  if(size<4){
    CasoBase(abbcompleto, size, res);
  }else{
	//Declaracion de variables
	int raiz=abbcompleto[0],
	    sizemenor=0,
	    sizemayor=0;
	int menores[size-1]={0},
	    mayores[size-1]={0};

	//Separar elementos en ramas
	for(int n=1;n<size;++n){
		if(abbcompleto[n]<raiz){
			menores[sizemenor]=abbcompleto[n];
			sizemenor++;
		}
		if(abbcompleto[n]>=raiz){
			mayores[sizemayor]=abbcompleto[n];
			sizemayor++;
		}
	}

	//Dibujar caso mas externo
	res[raiz][menores[0]]=true;
	res[raiz][mayores[0]]=true;

	//Lamadas recursivas
	DyV(menores, sizemenor, res);//Llamada para los elementos menores
	DyV(mayores, sizemayor, res);//Llamada para los elementos mayores
  }
}
//--------------------------------------------------
//--------------------------------------------------Main--------------------------------------------------

int main(){
int abb[]={22,15,3,1,8,7,4,13,9,12,10,40,30,23,34,45,48,53,51};
int tam=sizeof(abb)/sizeof(int);//Numero de elementos:bytes que ocupan todos los elementos / bytes que ocupa un entero

int valormax=-1;
for(int a:abb){
  if(a >= valormax) valormax=a;
}

cout << "El abb tiene "<<tam<< " elementos y su max valor es "<<valormax<<endl;
valormax++;

bool **res=new bool*[valormax];//Creacion de una matriz dinamica
for(int k=0;k<valormax;++k){
  res[k]=new bool[valormax];
}
clock_t tantes=clock();
//Aqui deberia empezar la medicion del tiempo
DyV(abb, tam, res);
//Aqui deberia acabar la medicion del tiempo
clock_t tdespues=clock();

//Finalmente mostramos el resultado en la matriz de adyacencia
for(int i=1;i<valormax;++i){
  for(int j=1;j<valormax;++j){
    if(res[i][j]==true)cout<<"t ";
    else cout<<"f ";
  }
  cout<<endl;
}

//

cout<< (double)(tdespues-tantes) / CLOCKS_PER_SEC << endl;
//Destruimos la matriz dinamica
for(int k=0;k<valormax;++k){
  delete []res[k];
}
delete []res;

return 0;
}

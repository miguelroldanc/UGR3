#include <iostream>
using namespace std;

//--------------------------------------------------Funciones--------------------------------------------------

void DibujarSubArbol(int abbsub[], int tamsub, bool** matrizdibujo){
  int posmenor=-1,
      posmayor=-1;
  bool menorEncontrado=false,
       mayorEncontrado=false;

  for(int i=0;i<tamsub;i++){
    for(int a=i+1;a<tamsub && menorEncontrado==false;++a){
      if(abbsub[a]<abbsub[i]){
	  menorEncontrado=true;
	  posmenor=a;
      }
    }

    for(int b=i+1;b<tamsub && mayorEncontrado==false;++b){
      if(abbsub[b]>=abbsub[i]){
  	  mayorEncontrado=true;
	  posmayor=b;
      }
    }
  //Si hemos encontrado el menor y el mayor de ese elemento los dibujamos en la matriz
    if(menorEncontrado){
	  matrizdibujo[abbsub[i]][abbsub[posmenor]]=true;
    }
    if(mayorEncontrado){
	  matrizdibujo[abbsub[i]][abbsub[posmayor]]=true;
    }

    if((mayorEncontrado&&menorEncontrado) || !(mayorEncontrado && menorEncontrado)){
	++i;
    }else{
	i+=2;
    }

    menorEncontrado=false;mayorEncontrado=false;
  }
}
//--------------------------------------------------

void DibujarMatriz(int abb[], int tam, bool** matrizdibujo){
int raiz=abb[0];
//En el peor caso (solo hay elementos mayores o menores) sabemos que es el tamaño sin contar el primer elemento
int menores[tam-1]={0},
    mayores[tam-1]={0};
//Insertamos elementos en las listas creadas
int contMenor=0,
    contMayor=0;

for(int n=1;n<tam;++n){
  if(abb[n]<raiz){
    menores[contMenor]=abb[n];
    contMenor++;
  }
  if(abb[n]>=raiz){
    mayores[contMayor]=abb[n];
    contMayor++;
  }
}
//El primero de cada lista es hijo del elemento raiz
matrizdibujo[raiz][menores[0]]=true;
matrizdibujo[raiz][mayores[0]]=true;

  DibujarSubArbol(menores, contMenor, matrizdibujo);
  DibujarSubArbol(mayores, contMayor, matrizdibujo);
}
//--------------------------------------------------
//--------------------------------------------------Main--------------------------------------------------

int main(){
//Declaracion del arbol binario de busqueda
int abb[]={22,15,3,1,8,7,4,13,9,12,10,40,30,23,34,45,48,53,51};//Numero de elementos:bytes que ocupan todos los elementos/bytes que ocupa un entero
int tam=sizeof(abb)/sizeof(int);

int max=-1;
for(int a:abb){
  if(a >= max) max=a;
}

cout << "El abb tiene "<<tam<< " elementos y su max valor es "<<max<<endl;
max++;

bool **res=new bool*[max];//Creacion de una matriz dinamica
for(int k=0;k<max;++k){
  res[k]=new bool[max];
}


clock_t tantes=clock();
//Aqui deberia empezar la medicion del tiempo
DibujarMatriz(abb, tam, res);
//Aqui deberia acabar la medicion del tiempo
clock_t tdespues=clock();
//Finalmente mostramos el resultado en la matriz de adyacencia
for(int i=1;i<max-1;++i){
  for(int j=1;j<max;++j){
    if(res[i][j]==true)cout<<"t ";
    else cout<<"f ";
  }
  cout<<endl;
}
cout<< (double)(tdespues-tantes) / CLOCKS_PER_SEC << endl;
//Destruimos la matriz dinamica
for(int k=0;k<max;++k){
  delete []res[k];
}
delete []res;

return 0;
}
